#include<iostream>
#include<stdlib.h>
#include<iomanip>
#include<mpi.h>
#include<arm_neon.h>
using namespace std;
int num_proc = 8;
const int n = 2500;
int NUM_THREADS = 8;
float A[n][n];
double MPI_pipeline() {
        // 与clycle分配相同，只有是0号进程，才进行初始化工作，此处不赘述
        // 0号进程负责任务的初始分发工作，非0号进程负责任务的接收工作
        //这里的代码也与cycle分配完全一样，同样不再赘述
        // 做消元运算
        int pre_proc = (rank + (size - 1)) % size;
        int next_proc = (rank + 1) % size;
        for (int k = 0; k < N; k++) {
            // 如果除法操作是本进程负责的任务，并将除法结果广播
            if (k % size == rank) {
                for (int j = k + 1; j < N; j++) {
                    matrix[k][j] /= matrix[k][k];  }
                matrix[k][k] = 1;
                MPI_Send(&matrix[k][0], N, MPI_FLOAT, next_proc, 1, MPI_COMM_WORLD); }
            // 其余进程接收除法行的结果
            else {
                MPI_Recv(&matrix[k][0], N, MPI_FLOAT, pre_proc, 1, 
                MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                if (next_proc != k % size) {
                     MPI_Send(&matrix[k][0], N, MPI_FLOAT, next_proc, 1, MPI_COMM_WORLD); } }
        // 进行消元操作
	int start = rank * task_num;
        int end = (rank + 1) * task_num < N ? (rank + 1) * task_num : N;
        for (int k = 0; k < N; k++) {
        // 如果除法操作是本进程负责的任务，并将除法结果广播
            if (k >= start && k < end) {
                for (int j = k + 1; j < N; j++) {
                    matrix[k][j] /= matrix[k][k];  }
                matrix[k][k] = 1;
                for (int p = 0; p < size; p++) {
                    if (p != rank) {
                        MPI_Send(&matrix[k][0], N, MPI_FLOAT, p, 0, MPI_COMM_WORLD); }  }  }
            else { // 其余进程接收除法行的结果
                MPI_Recv(&matrix[k][0], N, MPI_FLOAT, MPI_ANY_SOURCE, 0, 
                MPI_COMM_WORLD, MPI_STATUS_IGNORE);  }
            //下面进行消元操作
            for (int i = max(k + 1, start); i < end; i++) {
                for (int j = k + 1; j < N; j++) {
                    matrix[i][j] = matrix[i][j] - matrix[i][k] * matrix[k][j];}
                matrix[i][k] = 0; }  }
    }
int main(int argc, char* argv[])
{
    MPI_Init(NULL, NULL);
    int rank;
    MPI_pipeline();
    Gauss_mpi(rank);
    MPI_Finalize();
    return 0;
}