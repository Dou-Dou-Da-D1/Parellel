#include<iostream>
#include<stdlib.h>
#include<iomanip>
#include<mpi.h>
#include<arm_neon.h>
using namespace std;
int num_proc = 8;
const int n = 2500;
int NUM_THREADS = 8;
float A[n][n];

void Gauss_mpi(int rank)
{
    int j;
    double start, end;
    int len = (n - n % num_proc) / num_proc;
    int r1 = rank * len;
    int r2 = (rank + 1) * len;
    if (rank == num_proc - 1)
    {
        r2 = n;
    }
    if (rank == 0)
    {
        srand((unsigned)time(NULL));
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < i; j++)
        {
            A[i][j] = 0;
        }
        A[i][i] = 1.0;
        for (int j = i + 1; j < n; j++)
        {
            A[i][j] = rand() % 10000;//模取一万保证矩阵数据不会过大
        }
    }
    for (int k = 0; k < n; k++)
    {
        for (int i = k + 1; i < n; i++)
        {
            for (int j = 0; j < n; j++)
            {
                A[i][j] += A[k][j];
                A[i][j] = float(int(A[i][j]) % 10000);//同理
            }
        }
    }
        for (j = 1; j < num_proc; j++)
        {
            int t1 = j* len;
            int t2 = (j + 1) * len;
            if (j == num_proc - 1)
            {
                t2 = n;
            }
            MPI_Send(&A[t1][0], n * (t2 - t1), MPI_FLOAT, j,0,MPI_COMM_WORLD);
        }
    }
    else
    {
        MPI_Recv(&A[r1][0], n * (r2 - r1), MPI_FLOAT, 0,0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
    }
    MPI_Barrier(MPI_COMM_WORLD);
    start = MPI_Wtime();
    for (int k = 0; k < n; k++)
    {
        if (k >= r1 && k <r2)
        {
            for (j = k + 1; j < n; j++)
            {
                A[k][j] = A[k][j] / A[k][k];
            }
            A[k][k] = 1.0;
            for (j = rank+1; j < num_proc; j++)
            {
                MPI_Send(&A[k][0], n, MPI_FLOAT, j, 2, MPI_COMM_WORLD);
            }
        }
        else
        {
            int tmp = k / len;
            if (tmp < rank)
            {
                MPI_Recv(&A[k][0], n, MPI_FLOAT, tmp, 2, MPI_COMM_WORLD, MPI_STATUSES_IGNORE);
            }
        }
        for (int i = max(r1, k+1); i < r2; i++)
        {
            for (j = k + 1; j < n; j++)
            {
                A[i][j] = A[i][j] - A[i][k] * A[k][j];
            }
            A[i][k] = 0;
        }
    }
    end = MPI_Wtime();
    if (rank == 7)
    {
        cout << "高斯消元mpi块划分优化" << (end - start) * 1000 << "ms" << endl;
    }
}
int main(int argc, char* argv[])
{
    MPI_Init(NULL, NULL);
    int rank;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    Gauss_mpi(rank);
    MPI_Finalize();
    return 0;
}