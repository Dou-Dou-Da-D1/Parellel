#include<iostream>
#include<stdlib.h>
#include<iomanip>
#include<mpi.h>
#include<omp.h>
#include <xmmintrin.h> //SSE
#include <emmintrin.h> //SSE2
#include <pmmintrin.h> //SSE3
#include <tmmintrin.h> //SSSE3
#include <smmintrin.h> //SSE4.1
#include <nmmintrin.h> //SSSE4.2
#include <immintrin.h> //AVX、AVX2
using namespace std;
int num_proc = 8;
const int n = 500;
int NUM_THREADS = 8;
float A[n][n];
void Gauss_mpi_loop_omp(int rank)
{
    int i = 0;
    int j = 0;
    int k = 0;
    float temp = 0;
    double start, end;
    if (rank == 0)
    {
            srand((unsigned)time(NULL));
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < i; j++)
        {
            A[i][j] = 0;
        }
        A[i][i] = 1.0;
        for (int j = i + 1; j < n; j++)
        {
            A[i][j] = rand() % 10000;//模取一万保证矩阵数据不会过大
        }
    }
    for (int k = 0; k < n; k++)
    {
        for (int i = k + 1; i < n; i++)
        {
            for (int j = 0; j < n; j++)
            {
                A[i][j] += A[k][j];
                A[i][j] = float(int(A[i][j]) % 10000);//同理
            }
        }
    }
        for (k = 0; k < n; k++)
        {
            int tmp = k % num_proc;
            if (tmp != 0)
            {
                MPI_Send(&A[k][0], n, MPI_FLOAT, tmp, 0, MPI_COMM_WORLD);
            }
        }
    }
    else
    {
        for (k = 0; k < n; k++)
        {
            int tmp = k % num_proc;
            if (tmp == rank)
            {
                MPI_Recv(&A[k][0], n, MPI_FLOAT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            }
        }
    }
    MPI_Barrier(MPI_COMM_WORLD);
    start = MPI_Wtime();
#pragma omp parallel num_threads(NUM_THREADS), private(i, j, k, temp)
    for (k = 0; k < n; k++)
    {
        #pragma omp single
        if (k % num_proc == rank)
        {
            temp = A[k][k];
            for (j = k + 1; j < n; j++)
            {
                A[k][j] = A[k][j] / temp;
            }
            A[k][k] = 1.0;
            for (j = rank + 1; j < num_proc; j++)
            {
                MPI_Send(&A[k][0], n, MPI_FLOAT, j, 2, MPI_COMM_WORLD);
            }
        }
        else
        {
            int tmp = k % num_proc;
            if (tmp < rank)
            {
                MPI_Recv(&A[k][0], n, MPI_FLOAT, tmp, 2, MPI_COMM_WORLD, MPI_STATUSES_IGNORE);
            }
        }
        #pragma omp for schedule(guided)
        for (i = 0; i < n; i++)
        {
            if (i % num_proc == rank && i > k)
            {
                temp = A[i][k];
                for (j = k + 1; j < n; j++)
                {
                    A[i][j] = A[i][j] - temp * A[k][j];
                }
                A[i][k] = 0;
            }
        }
    }
    end = MPI_Wtime();
    if (rank == num_proc-1)
    {
        cout << "高斯消元mpi循环划分openmp优化" << (end - start) * 1000 << "ms" << endl;
    }
}
int main(int argc, char* argv[])
{
    MPI_Init(NULL, NULL);
    int rank;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    Gauss_mpi_loop_omp(rank);
    MPI_Finalize();
    return 0;
}
