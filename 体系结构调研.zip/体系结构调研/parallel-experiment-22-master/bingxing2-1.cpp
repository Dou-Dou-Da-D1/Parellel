#include <pmmintrin.h>
#include <xmmintrin.h>
#include <emmintrin.h>
#include <smmintrin.h>
#include <tmmintrin.h>
#include <nmmintrin.h>
#include <iostream>
#include <sstream>
#include <fstream>
#include <immintrin.h> //AVX��AVX2
//#include <windows.h>
#include <sys/time.h>
using namespace std;

const int matrix_size = 300;
float matrix[matrix_size][matrix_size];


void initializeMatrix()
{
	for (int i = 0; i < matrix_size; i++)
	{
		for (int j = 0; j < matrix_size; j++)
		{
			matrix[i][j] = 0;
		}
		matrix[i][i] = 1.0;
		for (int j = i + 1; j < matrix_size; j++)
			matrix[i][j] = rand();
	}

	for (int k = 0; k < matrix_size; k++)
	{
		for (int i = k + 1; i < matrix_size; i++)
		{
			for (int j = 0; j < matrix_size; j++)
			{
				matrix[i][j] += matrix[k][j];
			}
		}
	}
}


void ordinaryGaussianElimination()
{
	for (int k = 0; k < matrix_size; k++)
	{
		for (int j = k + 1; j < matrix_size; j++)
		{
			matrix[k][j] = matrix[k][j] * 1.0 / matrix[k][k];
		}
		matrix[k][k] = 1.0;

		for (int i = k + 1; i < matrix_size; i++)
		{
			for (int j = k + 1; j < matrix_size; j++)
			{
				matrix[i][j] = matrix[i][j] - matrix[i][k] * matrix[k][j];
			}
			matrix[i][k] = 0;
		}
	}
}


__m128 va, vt, vx, vaij, vaik, vakj;
void sseGaussianElimination()
{
	for (int k = 0; k < matrix_size; k++)
	{
		vt = _mm_set_ps(matrix[k][k], matrix[k][k], matrix[k][k], matrix[k][k]);
		int j;
		for (j = k + 1; j + 4 <= matrix_size; j += 4)
		{
			va = _mm_loadu_ps(&(matrix[k][j]));
			va = _mm_div_ps(va, vt);
			_mm_store_ps(&(matrix[k][j]), va);
		}

		for (; j < matrix_size; j++)
		{
			matrix[k][j] = matrix[k][j] * 1.0 / matrix[k][k];

		}
		matrix[k][k] = 1.0;

		for (int i = k + 1; i < matrix_size; i++)
		{
			vaik = _mm_set_ps(matrix[i][k], matrix[i][k], matrix[i][k], matrix[i][k]);

			for (j = k + 1; j + 4 <= matrix_size; j += 4)
			{
				vakj = _mm_loadu_ps(&(matrix[k][j]));
				vaij = _mm_loadu_ps(&(matrix[i][j]));
				vx = _mm_mul_ps(vakj, vaik);
				vaij = _mm_sub_ps(vaij, vx);

				_mm_store_ps(&matrix[i][j], vaij);
			}

			for (; j < matrix_size; j++)
			{
				matrix[i][j] = matrix[i][j] - matrix[i][k] * matrix[k][j];
			}

			matrix[i][k] = 0;
		}
	}
}


__m256 va2, vt2, vx2, vaij2, vaik2, vakj2;
void avx
256GaussianElimination()
{
	for (int k = 0; k < matrix_size; k++)
	{
		vt2 = _mm256_set_ps(matrix[k][k], matrix[k][k], matrix[k][k], matrix[k][k], matrix[k][k], matrix[k][k], matrix[k][k], matrix[k][k]);
		int j;
		for (j = k + 1; j + 8 <= matrix_size; j += 8)
		{
			va2 = _mm256_loadu_ps(&(matrix[k][j]));
			va2 = _mm256_div_ps(va2, vt2);
			_mm256_store_ps(&(matrix[k][j]), va2);
		}

		for (; j < matrix_size; j++)
		{
			matrix[k][j] = matrix[k][j] * 1.0 / matrix[k][k];

		}
		matrix[k][k] = 1.0;

		for (int i = k + 1; i < matrix_size; i++)
		{
			vaik2 = _mm256_set_ps(matrix[i][k], matrix[i][k], matrix[i][k], matrix[i][k], matrix[i][k], matrix[i][k], matrix[i][k], matrix[i][k]);

			for (j = k + 1; j + 8 <= matrix_size; j += 8)
			{
				vakj2 = _mm256_loadu_ps(&(matrix[k][j]));
				vaij2 = _mm256_loadu_ps(&(matrix[i][j]));
				vx2 = _mm256_mul_ps(vakj2, vaik2);
				vaij2 = _mm256_sub_ps(vaij2, vx2);

				_mm256_store_ps(&matrix[i][j], vaij2);
			}

			for (; j < matrix_size; j++)
			{
				matrix[i][j] = matrix[i][j] - matrix[i][k] * matrix[k][j];
			}

			matrix[i][k] = 0;
		}
	}
}

__m512 va3, vt3, vx3, vaij3, vaik3, vakj3;
void avx512GaussianElimination()
{
	for (int k = 0; k < matrix_size; k++)
	{
		float temp[16] = { matrix[k][k], matrix[k][k], matrix[k][k], matrix[k][k], matrix[k][k], matrix[k][k], matrix[k][k], matrix[k][k], matrix[k][k], matrix[k][k], matrix[k][k], matrix[k][k], matrix[k][k], matrix[k][k], matrix[k][k], matrix[k][k] };
		vt3 = _mm512_loadu_ps(temp);
		int j;
		for (j = k + 1; j + 16 <= matrix_size; j += 16)
		{
			va3 = _mm512_loadu_ps(&(matrix[k][j]));
			va3 = _mm512_div_ps(va3, vt3);
			_mm512_store_ps(&(matrix[k][j]), va3);
		}

		for (; j < matrix_size; j++)
		{
			matrix[k][j] = matrix[k][j] * 1.0 / matrix[k][k];

		}
		matrix[k][k] = 1.0;

		for (int i = k + 1; i < matrix_size; i++)
		{
			vaik3 = _mm512_set_ps(matrix[i][k], matrix[i][k], matrix[i][k], matrix[i][k], matrix[i][k], matrix[i][k], matrix[i][k], matrix[i][k], matrix[i][k], matrix[i][k], matrix[i][k], matrix[i][k], matrix[i][k], matrix[i][k], matrix[i][k], matrix[i][k]);

			for (j = k + 1; j + 16 <= matrix_size; j += 16)
			{
				vakj3 = _mm512_loadu_ps(&(matrix[k][j]));
				vaij3 = _mm512_loadu_ps(&(matrix[i][j]));
				vx3 = _mm512_mul_ps(vakj3, vaik3);
				vaij3 = _mm512_sub_ps(vaij3, vx3);

				_mm512_store_ps(&matrix[i][j], vaij3);
			}

			for (; j < matrix_size; j++)
			{
				matrix[i][j] = matrix[i][j] - matrix[i][k] * matrix[k][j];
			}

			matrix[i][k] = 0;
		}
	}
}

int main()
{
	struct timeval head, tail;
	double seconds;
	initializeMatrix();
	gettimeofday(&head, NULL);//��ʼ��ʱ
	ordinaryGaussianElimination();
	gettimeofday(&tail, NULL);//������ʱ
	seconds = ((tail.tv_sec - head.tv_sec) * 1000000 + (tail.tv_usec - head.tv_usec)) / 1000.0;//��λ ms
	cout << "ordinaryGaussianElimination: " << seconds << " ms" << endl;

	initializeMatrix();
	gettimeofday(&head, NULL);//��ʼ��ʱ
	sseGaussianElimination();
	gettimeofday(&tail, NULL);//������ʱ
	seconds = ((tail.tv_sec - head.tv_sec) * 1000000 + (tail.tv_usec - head.tv_usec)) / 1000.0;//��λ ms
	cout << "sseGaussianElimination: " << seconds << " ms" << endl;

	initializeMatrix();
	gettimeofday(&head, NULL);//��ʼ��ʱ
	avx256GaussianElimination();
	gettimeofday(&tail, NULL);//������ʱ
	seconds = ((tail.tv_sec - head.tv_sec) * 1000000 + (tail.tv_usec - head.tv_usec)) / 1000.0;//��λ ms
	cout << "avx256GaussianElimination: " << seconds << " ms" << endl;

	initializeMatrix();
	gettimeofday(&head, NULL);//��ʼ��ʱ
	avx512GaussianElimination();
	gettimeofday(&tail, NULL);//������ʱ
	seconds = ((tail.tv_sec - head.tv_sec) * 1000000 + (tail.tv_usec - head.tv_usec)) / 1000.0;//��λ ms
	cout << "avx512GaussianElimination: " << seconds << " ms" << endl;

	return 0;
}