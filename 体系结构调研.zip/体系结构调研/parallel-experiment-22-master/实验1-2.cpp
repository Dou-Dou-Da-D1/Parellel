#include <iostream>
#include <chrono>
#include <ratio>
using namespace std;
#define lli unsigned long long int
const lli N = 12288;
lli a[N];
int xhcs = 100;

void begin()
{
    for (lli i = 0; i < N; i++)
        a[i] = i;
}

void ordinary()
{
    int sum = 0;
    auto start = std::chrono::high_resolution_clock::now();
    for (int i = 0; i < N; i++) {
         sum+= a[i];
    }
    auto end = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double, std::milli> elapsed = end - start;
    std::cout << "ord " << elapsed.count() / xhcs<< " ms" << std::endl;
}
void xunhuan()
{
    auto start = std::chrono::high_resolution_clock::now();
    for (int j = N; j > 1; j /= 2) {
        for (int i = 0; i < j / 2; i++) {
            a[i] = a[2 * i] + a[2 * i + 1];
        }
    }
    auto end = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double, std::milli> elapsed = end - start;
    std::cout << "xh " << elapsed.count()/xhcs << " ms" << std::endl;
}
void optimize()
{
    auto start = std::chrono::high_resolution_clock::now();
    lli sum1 = 0, sum2 = 0;
    for (int i = 0; i < N - 1; i += 2)
        sum1 += a[i], sum2 += a[i + 1];
    lli sum = sum1 + sum2;
    auto end = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double, std::milli> elapsed = end - start;
    std::cout << "opt " << elapsed.count() / xhcs << " ms" << std::endl;
}



int main()
{
    begin();
    ordinary();
  //  optimize();
  //  xunhuan();
}

