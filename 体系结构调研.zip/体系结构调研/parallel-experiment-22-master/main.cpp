#include <iostream>
#include <sstream>
#include <fstream>
#include <sys/time.h>
#include <arm_neon.h>

using namespace std;

unsigned int Array1[37960][1188] = { 0 };
unsigned int Array2[37960][1188] = { 0 };

void InitializeArray1()
{
    unsigned int value;
    ifstream infile("data1.txt");
    char buffer[100000] = { 0 };
    int index;
    while (infile.getline(buffer, sizeof(buffer)))
    {
        stringstream line(buffer);
        int flag = 0;
        while (line >> value)
        {
            if (flag == 0)
            {
                index = value;
                flag = 1;
            }
            int k = value % 32;
            int j = value / 32;
            int temp = 1 << k;
            Array1[index][1186 - j] += temp;
            Array1[index][1187] = 1;
        }
    }
}

void InitializeArray2()
{
    unsigned int value;
    ifstream infile("data2.txt");
    char buffer[100000] = { 0 };
    int index = 0;
    while (infile.getline(buffer, sizeof(buffer)))
    {
        stringstream line(buffer);
        int flag = 0;
        while (line >> value)
        {
            if (flag == 0)
            {
                Array2[index][1187] = value;
                flag = 1;
            }
            int k = value % 32;
            int j = value / 32;
            int temp = 1 << k;
            Array2[index][1186 - j] += temp;
        }
        index++;
    }
}

void OrdinaryAlgorithm()
{
    int i;
    for (i = 37959; i - 8 >= -1; i -= 8)
    {
        for (int j = 0; j < 14921; j++)
        {
            while (Array2[j][1187] <= i && Array2[j][1187] >= i - 7)
            {
                int index = Array2[j][1187];
                if (Array1[index][1187] == 1)
                {
                    for (int k = 0; k < 1187; k++)
                    {
                        Array2[j][k] = Array2[j][k] ^ Array1[index][k];
                    }
                    int num = 0, S_num = 0;
                    for (num = 0; num < 1187; num++)
                    {
                        if (Array2[j][num] != 0)
                        {
                            unsigned int temp = Array2[j][num];
                            while (temp != 0)
                            {
                                temp = temp >> 1;
                                S_num++;
                            }
                            S_num += num * 32;
                            break;
                        }
                    }
                    Array2[j][1187] = S_num - 1;
                }
                else
                {
                    for (int k = 0; k < 1187; k++)
                        Array1[index][k] = Array2[j][k];
                    Array1[index][1187] = 1;
                    break;
                }
            }
        }
    }

    for (i = i + 8; i >= 0; i--)
    {
        for (int j = 0; j < 14921; j++)
        {
            while (Array2[j][1187] == i)
            {
                if (Array1[i][1187] == 1)
                {
                    for (int k = 0; k < 1187; k++)
                    {
                        Array2[j][k] = Array2[j][k] ^ Array1[i][k];
                    }
                    int num = 0, S_num = 0;
                    for (num = 0; num < 1187; num++)
                    {
                        if (Array2[j][num] != 0)
                        {
                            unsigned int temp = Array2[j][num];
                            while (temp != 0)
                            {
                                temp = temp >> 1;
                                S_num++;
                            }
                            S_num += num * 32;
                            break;
                        }
                    }
                    Array2[j][1187] = S_num - 1;
                }
                else
                {
                    for (int k = 0; k < 1187; k++)
                        Array1[i][k] = Array2[j][k];
                    Array1[i][1187] = 1;
                    break;
                }
            }
        }
    }
}

void NeonParallel()
{
    int i;
    for (i = 37959; i - 8 >= -1; i -= 8)
    {
        for (int j = 0; j < 14921; j++)
        {
            while (Array2[j][1187] <= i && Array2[j][1187] >= i - 7)
            {
                int index = Array2[j][1187];
                if (Array1[index][1187] == 1)
                {
                    int k;
                    for (k = 0; k + 4 <= 1187; k += 4)
                    {
                        uint32x4_t va1 = vld1q_u32(&Array2[j][k]);
                        uint32x4_t va2 = vld1q_u32(&Array1[index][k]);
                        va1 = veorq_u32(va1, va2);
                        vst1q_u32(&Array2[j][k], va1);
                    }
                    for (; k < 1187; k++)
                    {
                        Array2[j][k] = Array2[j][k] ^ Array1[index][k];
                    }
                    int num = 0, S_num = 0;
                    for (num = 0; num < 1187; num++)
                    {
                        if (Array2[j][num] != 0)
                        {
                            unsigned int temp = Array2[j][num];
                            while (temp != 0)
                            {
                                temp = temp >> 1;
                                S_num++;
                            }
                            S_num += num * 32;
                            break;
                        }
                    }
                    Array2[j][1187] = S_num - 1;
                }
                else
                {
                    for (int k = 0; k < 1187; k++)
                        Array1[index][k] = Array2[j][k];
                    Array1[index][1187] = 1;
                    break;
                }
            }
        }
    }

    for (i = i + 8; i >= 0; i--)
    {
        for (int j = 0; j < 14921; j++)
        {
            while (Array2[j][1187] == i)
            {
                if (Array1[i][1187] == 1)
                {
                    int k;
                    for (k = 0; k + 4 <= 1187; k += 4)
                    {
                        uint32x4_t va1 = vld1q_u32(&Array2[j][k]);
                        uint32x4_t va2 = vld1q_u32(&Array1[i][k]);
                        va1 = veorq_u32(va1, va2);
                        vst1q_u32(&Array2[j][k], va1);
                    }
                    for (; k < 1187; k++)
                    {
                        Array2[j][k] = Array2[j][k] ^ Array1[i][k];
                    }
                    int num = 0, S_num = 0;
                    for (num = 0; num < 1187; num++)
                    {
                        if (Array2[j][num] != 0)
                        {
                            unsigned int temp = Array2[j][num];
                            while (temp != 0)
                            {
                                temp = temp >> 1;
                                S_num++;
                            }
                            S_num += num * 32;
                            break;
                        }
                    }
                    Array2[j][1187] = S_num - 1;
                }
                else
                {
                    for (int k = 0; k < 1187; k++)
                        Array1[i][k] = Array2[j][k];
                    Array1[i][1187] = 1;
                    break;
                }
            }
        }
    }
}

int main()
{
    struct timeval start_time, end_time;

    InitializeArray1();
    InitializeArray2();
    gettimeofday(&start_time, NULL);
    OrdinaryAlgorithm();
    gettimeofday(&end_time, NULL);
    double execution_time = ((end_time.tv_sec - start_time.tv_sec) * 1000000 + (end_time.tv_usec - start_time.tv_usec)) / 1000.0;
    cout << "Execution time of OrdinaryAlgorithm: " << execution_time << " ms" << endl;

    InitializeArray1();
    InitializeArray2();
    gettimeofday(&start_time, NULL);
    NeonParallel();
    gettimeofday(&end_time, NULL);
    execution_time = ((end_time.tv_sec - start_time.tv_sec) * 1000000 + (end_time.tv_usec - start_time.tv_usec)) / 1000.0;
    cout << "Execution time of NeonParallel: " << execution_time << " ms" << endl;

    return 0;
}
