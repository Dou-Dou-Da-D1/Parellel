#include <iostream>
#include <windows.h>
using namespace std;
const int N = 200;
int a[N];
int b[N][N];
int sum[N];
int xhcs = 100;
const int m = 1000;
int shuzu[m][16] = { 0 };
//һ��������64�ֽڣ���һ�����������
//768����һ�����漫��
/*ע��
intռ4���ֽڣ����������С�ֱ���48kb��1.25mb��262144����24mb
*/


void begin()
{
    for (int i = 0; i < N; i++)
        a[i] = i;
    for (int i = 0; i < N; i++)
        for (int j = 0; j < N; j++)
            b[i][j] = i + j;
    
}

void ordinary()
{
    long long int begin, end, freq;
    QueryPerformanceFrequency((LARGE_INTEGER*)&freq);
    QueryPerformanceCounter((LARGE_INTEGER*)&begin);
    for (int l = 0; l < xhcs; l++)
    {
        for (int i = 0; i < N; i++)
        {
            sum[i] = 0;
            for (int j = 0; j < N; j++)
                sum[i] += a[j] * b[j][i];
        }
    }
    QueryPerformanceCounter((LARGE_INTEGER*)&end);
    cout << "ord" << (end - begin) * 1000.0 / freq / xhcs << "ms" << endl;
}

void optimize()
{
    long long int begin, end, freq;
    QueryPerformanceFrequency((LARGE_INTEGER*)&freq);
    QueryPerformanceCounter((LARGE_INTEGER*)&begin);
    for (int l = 0; l < xhcs; l++)
    {
        for (int i = 0; i < N; i++)
            sum[i] = 0;
        for (int j = 0; j < N; j++)
            for (int i = 0; i < N; i++)
                sum[i] += a[j] * b[j][i];
    }
    QueryPerformanceCounter((LARGE_INTEGER*)&end);
    cout << "opt" << (end - begin) * 1000.0 / freq / xhcs << "ms" << endl;
}

void unroll()
{
    long long int begin, end, freq;
    QueryPerformanceFrequency((LARGE_INTEGER*)&freq);
    QueryPerformanceCounter((LARGE_INTEGER*)&begin);
    for (int l = 0; l < xhcs; l++)
    {
        for (int i = 0; i < N; i++)
            sum[i] = 0;
        for (int j = 0; j < N; j += 10)
        {
            int s0 = 0, s1 = 0, s2 = 0, s3 = 0, s4 = 0, s5 = 0, s6 = 0, s7 = 0, s8 = 0, s9 = 0;
            for (int i = 0; i < N; i++)
            {
                s0 += a[j + 0] * b[j + 0][i];
                s1 += a[j + 1] * b[j + 1][i];
                s2 += a[j + 2] * b[j + 2][i];
                s3 += a[j + 3] * b[j + 3][i];
                s4 += a[j + 4] * b[j + 4][i];
                s5 += a[j + 5] * b[j + 5][i];
                s6 += a[j + 6] * b[j + 6][i];
                s6 += a[j + 6] * b[j + 6][i];
                s7 += a[j + 7] * b[j + 7][i];
                s8 += a[j + 8] * b[j + 8][i];
                s9 += a[j + 9] * b[j + 9][i];
            }
            sum[j + 0] = s0;
            sum[j + 1] = s1;
            sum[j + 2] = s2;
            sum[j + 3] = s3;
            sum[j + 4] = s4;
            sum[j + 5] = s5;
            sum[j + 6] = s6;
            sum[j + 7] = s7;
            sum[j + 8] = s8;
            sum[j + 9] = s9;
        }
    }
    QueryPerformanceCounter((LARGE_INTEGER*)&end);
    cout << "xunhuan:" << (end - begin) * 1000.0 / freq / xhcs << "ms" << endl;
}

int main()
{
    
     begin();
     ordinary();
     //optimize();
     //xunhuan();
}