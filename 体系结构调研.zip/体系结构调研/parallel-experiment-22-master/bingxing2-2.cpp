# include <arm_neon.h> // use Neon
# include <sys/time.h>

# include <iostream>
using namespace std;

const int n = 1000;
float A[n][n];
float B[n][n];

float32x4_t va = vmovq_n_f32(0);
float32x4_t vx = vmovq_n_f32(0);
float32x4_t vaij = vmovq_n_f32(0);
float32x4_t vaik = vmovq_n_f32(0);
float32x4_t vakj = vmovq_n_f32(0);

void init() {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            A[i][j] = 0;
        }
        A[i][i] = 1.0;
        for (int j = i + 1; j < n; j++)
            A[i][j] = rand();
    }

    for (int k = 0; k < n; k++) {
        for (int i = k + 1; i < n; i++) {
            for (int j = 0; j < n; j++) {
                A[i][j] += A[k][j];
            }
        }
    }
}

double measureTime(void (*func)(), const string& label) {
    struct timeval head, tail;
    double seconds;

    gettimeofday(&head, NULL);
    func();
    gettimeofday(&tail, NULL);

    seconds = ((tail.tv_sec - head.tv_sec) * 1000000 + (tail.tv_usec - head.tv_usec)) / 1000.0;
    cout << label << ": " << seconds << " ms" << endl;

    return seconds;
}

typedef void (*TestFunc)();

void runTest(TestFunc testFunc, const string& label) {
    init();
    measureTime(testFunc, label);
}

void f_pro() {
    for (int k = 0; k < n; k++) {
        float32x4_t vt = vmovq_n_f32(A[k][k]);
        int j;
        for (j = k + 1; j + 4 <= n; j += 4) {
            va = vld1q_f32(&(A[k][j]));
            va = vdivq_f32(va, vt);
            vst1q_f32(&(A[k][j]), va);
        }

        for (; j < n; j++) {
            A[k][j] = A[k][j] * 1.0 / A[k][k];
        }
        A[k][k] = 1.0;

        for (int i = k + 1; i < n; i++) {
            vaik = vmovq_n_f32(A[i][k]);
            for (j = k + 1; j + 4 <= n; j += 4) {
                vakj = vld1q_f32(&(A[k][j]));
                vaij = vld1q_f32(&(A[i][j]));
                vx = vmulq_f32(vakj, vaik);
                vaij = vsubq_f32(vaij, vx);
                vst1q_f32(&A[i][j], vaij);
            }

            for (; j < n; j++) {
                A[i][j] = A[i][j] - A[i][k] * A[k][j];
            }
            A[i][k] = 0;
        }
    }
}

void f_pro_cache() {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < i; j++) {
            B[j][i] = A[i][j];
            A[i][j] = 0; 
        }
    }

    for (int k = 0; k < n; k++) {
        for (int j = k + 1; j < n; j++) {
            A[k][j] = A[k][j] * 1.0 / A[k][k];
        }
        A[k][k] = 1.0;

        for (int i = k + 1; i < n; i++) {
            for (int j = k + 1; j < n; j++) {
                A[i][j] = A[i][j] - B[k][i] * A[k][j];
            }
            //A[i][k] = 0;
        }
    }
}

int main() {
    runTest(f_pro, "f_pro");
    runTest(f_pro_cache, "f_pro_cache");

    return 0;
}
