#include <iostream>
#include<cstdlib>
#include<stdlib.h>
#include<pthread.h>
#include<immintrin.h>
#include<Windows.h>
#include<semaphore.h>
using namespace std;

const int N = 1000;
float mat[N][N];
float B[N];
float X[N];

//��ʼ��   //Ϊ��ֹ����nan�Գ�ʼ�����иĽ�������ܷ��ָ�ֵ�������Ǿ����ֵ����ȥ����ͬ
void init()
{
    srand(static_cast <unsigned> (1));
    for(int a=0;a<N;a++)
    {
        mat[a][a]=1.0;
        B[a]=(float)rand();
        X[a]=0;
        for(int b=a+1;b<N;b++)//��ʼ�������Ǿ���Ϊ�����
        {
            mat[a][b]=rand()%100;
        }
        for(int b=0;b<a;b++)//�����Ǿ���Ϊ0
        {
            mat[a][b]=0;
        }
    }
    for(int a=1;a<N;a++)//���ڼӷ�����
    {
       for(int b=0;b<N;b++)
       {
           mat[a][b]+=mat[a-1][b];
       }
    }
}
//��֤��ȷ
void print()
{
    for(int a=0;a<N;a++)
    {
        cout<<mat[67][a]<<" ";
    }
    cout<<endl;
}

//--------------------------------------------------------ƽ������------------------------------------------------------
//ƽ������ȫ����
void triviallast()
{
//��ȥ
    for(int k=0;k<N;k++)
    {
        for(int i=k+1;i<N;i++)
        {
            float factor=mat[i][k]/mat[k][k];
            for(int j=k+1;j<N;j++)
            {
                mat[i][j]-=factor*mat[k][j];
            }
            B[i]-=factor*B[k];
        }
    }
//�ش�
    for(int i=N-2;i>=0;i--)
    {
        float sum=B[i];
        for(int j=i+1;j<N;j++)
        {
            sum-=mat[i][j]*X[j];
        }
        X[i]=sum/mat[i][i];
    }
}
//ƽ��������ȥ���֣��Ż�����
void trivial()
{
    long long head, tail, freq;
	QueryPerformanceFrequency((LARGE_INTEGER*)&freq);
	QueryPerformanceCounter((LARGE_INTEGER*)&head);
    for(int k=0;k<N;k++)
    {
        for(int j=k+1;j<N;j++)
        {
            mat[k][j]/=mat[k][k];
        }
        mat[k][k]=1.0;

        for(int i=k+1;i<N;i++)
        {
            for(int j=k+1;j<N;j++)
            {
                mat[i][j]-=mat[i][k]*mat[k][j];
            }
            mat[i][k]=0;
        }
    }
    QueryPerformanceCounter((LARGE_INTEGER*)&tail);
    cout << "trivial: " << ((tail - head) * 1000.0 / freq) << "ms" << endl;
}

//--------------------------------------------------------AVX------------------------------------------------------
void AVX()
{
    long long head, tail, freq;
	QueryPerformanceFrequency((LARGE_INTEGER*)&freq);
	QueryPerformanceCounter((LARGE_INTEGER*)&head);
    for(int k=0;k<N;k++)
    {
        float kkt[8]={mat[k][k],mat[k][k],mat[k][k],mat[k][k],mat[k][k],mat[k][k],mat[k][k],mat[k][k]};
        __m256 kk = _mm256_loadu_ps(&kkt[0]);
        int j=k+1;
        for(;j+8<N;j+=8)
        {
            __m256 loadone = _mm256_loadu_ps(&mat[k][j]);
            __m256 loadtwo = _mm256_div_ps(loadone,kk);
            _mm256_storeu_ps(&mat[k][j],loadtwo);
        }
        for (; j < N; j++)
        {
            mat[k][j] /= mat[k][k];
        }
        mat[k][k]=1.0;

        for(int i=k+1;i<N;i++)
        {
            float ikt[8]={mat[i][k],mat[i][k],mat[i][k],mat[i][k],mat[i][k],mat[i][k],mat[i][k],mat[i][k]};
            __m256 ik = _mm256_loadu_ps(&ikt[0]);
            int nj=k+1;
            for(;nj+8<N;nj+=8)
            {
                __m256 loaone = _mm256_loadu_ps(&mat[i][nj]);
                __m256 loatwo = _mm256_loadu_ps(&mat[k][nj]);
                loatwo = _mm256_mul_ps(loatwo,ik);
                _mm256_storeu_ps(&mat[i][nj],_mm256_sub_ps(loaone,loatwo));
            }
            for(;nj<N;nj++)
            {
                mat[i][nj]-=mat[i][k]*mat[k][nj];
            }
            mat[i][k]=0;
        }
    }
    QueryPerformanceCounter((LARGE_INTEGER*)&tail);
    cout << "AVX: " << ((tail - head) * 1000.0 / freq) << "ms" << endl;
}

//--------------------------------------------------------dynamicpthread------------------------------------------------------
typedef struct{
    int k; //��ȥ�ִ�
    int t_id; //�߳�id
}dynamic_threadParam_t;

void *dynamic_threadfunc(void *param)
{
    dynamic_threadParam_t *p=(dynamic_threadParam_t*)param;
    int k=p->k;
    int t_id=p->t_id;
    int i = k + t_id +1;//��ȡ�Լ��ļ�������

    for(int j=k+1;j<N;j++)
    {
        mat[i][j]=mat[i][j]-mat[i][k]*mat[k][j];
    }
    mat[i][k]=0;
    pthread_exit(NULL);

}
void dynamic()
{
    long long head, tail, freq;
	QueryPerformanceFrequency((LARGE_INTEGER*)&freq);
	QueryPerformanceCounter((LARGE_INTEGER*)&head);
    for(int k=0;k<N;k++)
    {
        //���߳�������
        for(int j=k+1;j<N;j++)
        {
            mat[k][j]=mat[k][j]/mat[k][k];
        }
        mat[k][k]=1.0;

        //���������߳�
        int worker_count = N-1-k;//�����߳���
        pthread_t* handles = new pthread_t[worker_count];
        dynamic_threadParam_t* param = new dynamic_threadParam_t[worker_count];
        //��������
        for(int t_id=0;t_id<worker_count;t_id++)
        {
            param[t_id].k=k;
            param[t_id].t_id=t_id;
        }
        //�����߳�
        for(int t_id=0;t_id<worker_count;t_id++)
        {
            pthread_create(&handles[t_id],NULL,dynamic_threadfunc,&param[t_id]);
        }
        //���̹߳���ȴ�
        for(int t_id=0;t_id<worker_count;t_id++)
        {
            pthread_join(handles[t_id],NULL);
        }
    }
    QueryPerformanceCounter((LARGE_INTEGER*)&tail);
    cout << "dynamic: " << ((tail - head) * 1000.0 / freq) << "ms" << endl;
}

//--------------------------------------------------------staticpthread------------------------------------------------------
const int NUM_THREADS=4;

typedef struct{
   int t_id;//�߳�id
}sta_threadParam_t;


//��̬�߳�+�ź���ͬ��-------------------------
//�ź�������
sem_t sem_statwo_main;
sem_t sem_statwo_workerstart[NUM_THREADS]; // ÿ���߳����Լ�ר�����ź���
sem_t sem_statwo_workerend[NUM_THREADS];
//�̺߳�������
void *statwo_threadfunc(void *param) {
 sta_threadParam_t *p = (sta_threadParam_t *)param;
 int t_id = p -> t_id;

 for(int k = 0; k < N; k++)
 {
     sem_wait(&sem_statwo_workerstart[t_id]); // �������ȴ�������ɳ��������������Լ�ר�����ź�����

    //ѭ����������
    for(int i=k+1+t_id; i < N; i += NUM_THREADS)
    {
        //��ȥ
        for(int j=k+1;j<N;j++)
        {
            mat[i][j]=mat[i][j]-mat[i][k]*mat[k][j];
        }
        mat[i][k]=0.0;
    }
    sem_post(&sem_statwo_main);//�������߳�
    sem_wait(&sem_statwo_workerend[t_id]); //�������ȴ����̻߳��ѽ�����һ��
 }
 pthread_exit(NULL);
}
void statwo()
{
  long long head, tail, freq;
  QueryPerformanceFrequency((LARGE_INTEGER*)&freq);
  QueryPerformanceCounter((LARGE_INTEGER*)&head);
  //��ʼ���ź���
  sem_init(&sem_statwo_main,0,0);
  for(int i=0;i<NUM_THREADS;i++)
  {
      sem_init(&sem_statwo_workerstart[i],0,0);
      sem_init(&sem_statwo_workerend[i],0,0);
  }
  //�����߳�
  pthread_t handles[NUM_THREADS];
  sta_threadParam_t param[NUM_THREADS];
  for(int t_id=0;t_id<NUM_THREADS;t_id++)
  {
      param[t_id].t_id=t_id;
      pthread_create(&handles[t_id],NULL,statwo_threadfunc,&param[t_id]);
  }
  for(int k=0;k<N;k++)
  {
      //���߳�����������
      for(int j=k+1;j<N;j++)
      {
          mat[k][j]=mat[k][j]/mat[k][k];
      }
      mat[k][k]=1.0;
      //���ѹ����߳�
      for(int t_id=0;t_id<NUM_THREADS;t_id++)
      {
          sem_post(&sem_statwo_workerstart[t_id]);
      }
      //���߳�˯��
      for(int t_id=0;t_id<NUM_THREADS;t_id++)
      {
          sem_wait(&sem_statwo_main);
      }
      //���ѹ����߳̽�����һ�ִ���ȥ
      for(int t_id=0;t_id<NUM_THREADS;t_id++)
      {
          sem_post(&sem_statwo_workerend[t_id]);
      }
  }
  for(int t_id=0;t_id<NUM_THREADS;t_id++)
  {
      pthread_join(handles[t_id],NULL);
  }
  sem_destroy(sem_statwo_workerstart);
  sem_destroy(sem_statwo_workerend);
  sem_destroy(&sem_statwo_main);
  QueryPerformanceCounter((LARGE_INTEGER*)&tail);
  cout << "statwo: " << ((tail - head) * 1000.0 / freq) << "ms" << endl;
}

//��̬�߳�+�ź���ͬ��+����ѭ��-------------------------
//�ź�������
sem_t sem_stathr_leader;
sem_t sem_stathr_division[NUM_THREADS-1];
sem_t sem_stathr_elimination[NUM_THREADS-1];
//�̺߳�������
void *stathr_threadfunc(void *param) {
    sta_threadParam_t *p=(sta_threadParam_t*)param;
    int t_id=p->t_id;

    for(int k=0;k<N;k++)
    {
        //1���߳���ɳ���
        if(t_id==0)
        {
            for(int j=k+1;j<N;j++)
            {
                mat[k][j]=mat[k][j]/mat[k][k];
            }
            mat[k][k]=1.0;
        }
        else
        {
            sem_wait(&sem_stathr_division[t_id-1]);
        }
        //0�̻߳������������߳�
        if(t_id==0)
        {
            for(int i=0;i<NUM_THREADS-1;i++)
            {
                sem_post(&sem_stathr_division[i]);
            }
        }
        //���񻮷�
        for(int i=k+1+t_id;i<N;i+=NUM_THREADS)
        {
            //��ȥ
            for(int j=k+1;j<N;j++)
            {
                mat[i][j]=mat[i][j]-mat[i][k]*mat[k][j];
            }
            mat[i][k]=0.0;
        }
        if(t_id==0)
        {
            for(int i=0;i<NUM_THREADS-1;i++)
            {
                sem_wait(&sem_stathr_leader);
            }
            for(int i=0;i<NUM_THREADS-1;i++)
            {
                sem_post(&sem_stathr_elimination[i]);
            }
        }
        else
        {
            sem_post(&sem_stathr_leader);
            sem_wait(&sem_stathr_elimination[t_id-1]);
        }
    }
    pthread_exit(NULL);
}
void stathr()
{
    long long head, tail, freq;
    QueryPerformanceFrequency((LARGE_INTEGER*)&freq);
    QueryPerformanceCounter((LARGE_INTEGER*)&head);
    //��ʼ���ź���
    sem_init(&sem_stathr_leader,0,0);
    for(int i=0;i<NUM_THREADS-1;i++)
    {
        sem_init(&sem_stathr_division[i],0,0);
        sem_init(&sem_stathr_elimination[i],0,0);
    }
    //�����߳�
    pthread_t handles[NUM_THREADS];
    sta_threadParam_t param[NUM_THREADS];
    for(int t_id=0;t_id<NUM_THREADS;t_id++)
    {
        param[t_id].t_id=t_id;
        pthread_create(&handles[t_id],NULL,stathr_threadfunc,&param[t_id]);
    }
    for(int t_id=0;t_id<NUM_THREADS;t_id++)
    {
        pthread_join(handles[t_id],NULL);
    }
    sem_destroy(sem_stathr_division);
    sem_destroy(sem_stathr_elimination);
    sem_destroy(&sem_stathr_leader);
    QueryPerformanceCounter((LARGE_INTEGER*)&tail);
    cout << "stathr: " << ((tail - head) * 1000.0 / freq) << "ms" << endl;
}

//��̬�߳�+barrierͬ��-------------------------
//barrier����
pthread_barrier_t barrier_stathr_division;
pthread_barrier_t barrier_stathr_elimination;
pthread_barrier_t barrier_stathr_setzero;
const int divthreadnum=1;

//ˮƽ����
//�̺߳���
void *stathr_bh_threadfunc(void *param){
    sta_threadParam_t *p=(sta_threadParam_t*)param;
    int t_id=p->t_id;

    for(int k=0;k<N;k++)
    {
        //1���߳���ɳ���
        if(t_id<divthreadnum)
        {
            for(int j=k+1+t_id;j<N;j+=divthreadnum)
            {
                mat[k][j]=mat[k][j]/mat[k][k];
            }
            mat[k][k]=1.0;
        }
        //��һ��ͬ����
        pthread_barrier_wait(&barrier_stathr_division);
        //��������
        for(int i=k+1+t_id;i<N;i+=NUM_THREADS)
        {
            //��ȥ
            for(int j=k+1;j<N;j++)
            {
                mat[i][j]=mat[i][j]-mat[i][k]*mat[k][j];
            }
            mat[i][k]=0.0;
        }
        //�ڶ���ͬ����
        pthread_barrier_wait(&barrier_stathr_elimination);
    }
    pthread_exit(NULL);
}
void stathr_bh()
{
    long long head, tail, freq;
    QueryPerformanceFrequency((LARGE_INTEGER*)&freq);
    QueryPerformanceCounter((LARGE_INTEGER*)&head);
    //��ʼ��barrier
    pthread_barrier_init(&barrier_stathr_division,NULL,NUM_THREADS);
    pthread_barrier_init(&barrier_stathr_elimination,NULL,NUM_THREADS);
    //�����߳�
    pthread_t handles[NUM_THREADS];
    sta_threadParam_t param[NUM_THREADS];
    for(int t_id=0;t_id<NUM_THREADS;t_id++)
    {
        param[t_id].t_id=t_id;
        pthread_create(&handles[t_id],NULL,stathr_bh_threadfunc,&param[t_id]);
    }
    for(int t_id=0;t_id<NUM_THREADS;t_id++)
    {
        pthread_join(handles[t_id],NULL);
    }
    pthread_barrier_destroy(&barrier_stathr_division);
    pthread_barrier_destroy(&barrier_stathr_elimination);
    QueryPerformanceCounter((LARGE_INTEGER*)&tail);
    cout << "stathr_bh: " << ((tail - head) * 1000.0 / freq) << "ms" << endl;
}

//��ֱ����
//�̺߳���
void *stathr_bv_threadfunc(void *param){
    sta_threadParam_t *p=(sta_threadParam_t*)param;
    int t_id=p->t_id;

    for(int k=0;k<N;k++)
    {
        //1���߳���ɳ���
        if(t_id<divthreadnum)
        {
            for(int j=k+1+t_id;j<N;j+=divthreadnum)
            {
                mat[k][j]=mat[k][j]/mat[k][k];
            }
            mat[k][k]=1.0;
        }
        //��һ��ͬ����
        pthread_barrier_wait(&barrier_stathr_division);
        //��������
        for(int j=k+1+t_id;j<N;j+=NUM_THREADS)
        {
            for(int i=k+1;i<N;i++)
            {
                mat[i][j]=mat[i][j]-mat[i][k]*mat[k][j];
            }
        }
        //�ڶ���ͬ����
        pthread_barrier_wait(&barrier_stathr_elimination);
        for(int i=k+1+t_id;i<N;i+=NUM_THREADS)
        {
            mat[i][k]=0.0;
        }
        //������ͬ����
        pthread_barrier_wait(&barrier_stathr_setzero);
    }
    pthread_exit(NULL);
}
void stathr_bv()
{
    long long head, tail, freq;
    QueryPerformanceFrequency((LARGE_INTEGER*)&freq);
    QueryPerformanceCounter((LARGE_INTEGER*)&head);
    //��ʼ��barrier
    pthread_barrier_init(&barrier_stathr_division,NULL,NUM_THREADS);
    pthread_barrier_init(&barrier_stathr_elimination,NULL,NUM_THREADS);
    pthread_barrier_init(&barrier_stathr_setzero,NULL,NUM_THREADS);
    //�����߳�
    pthread_t handles[NUM_THREADS];
    sta_threadParam_t param[NUM_THREADS];
    for(int t_id=0;t_id<NUM_THREADS;t_id++)
    {
        param[t_id].t_id=t_id;
        pthread_create(&handles[t_id],NULL,stathr_bv_threadfunc,&param[t_id]);
    }
    for(int t_id=0;t_id<NUM_THREADS;t_id++)
    {
        pthread_join(handles[t_id],NULL);
    }
    pthread_barrier_destroy(&barrier_stathr_division);
    pthread_barrier_destroy(&barrier_stathr_elimination);
    pthread_barrier_destroy(&barrier_stathr_setzero);
    QueryPerformanceCounter((LARGE_INTEGER*)&tail);
    cout << "stathr_bv: " << ((tail - head) * 1000.0 / freq) << "ms" << endl;
}
//�̺߳���
void *stathr_bvnew_threadfunc(void *param){
    sta_threadParam_t *p=(sta_threadParam_t*)param;
    int t_id=p->t_id;

    for(int k=0;k<N;k++)
    {
        for(int j=k+1+t_id;j<N;j+=NUM_THREADS)
        {
            mat[k][j]=mat[k][j]/mat[k][k];
            for(int i=k+1;i<N;i++)
            {
                mat[i][j]=mat[i][j]-mat[i][k]*mat[k][j];
            }
            mat[k][k]=1.0;
        }
        pthread_barrier_wait(&barrier_stathr_elimination);
        for(int i=k+1+t_id;i<N;i+=NUM_THREADS)
        {
            mat[i][k]=0.0;
        }
        pthread_barrier_wait(&barrier_stathr_setzero);
    }
    pthread_exit(NULL);
}
void stathr_bvnew()
{
    long long head, tail, freq;
    QueryPerformanceFrequency((LARGE_INTEGER*)&freq);
    QueryPerformanceCounter((LARGE_INTEGER*)&head);
    //��ʼ��barrier
    pthread_barrier_init(&barrier_stathr_elimination,NULL,NUM_THREADS);
    pthread_barrier_init(&barrier_stathr_setzero,NULL,NUM_THREADS);
    //�����߳�
    pthread_t handles[NUM_THREADS];
    sta_threadParam_t param[NUM_THREADS];
    for(int t_id=0;t_id<NUM_THREADS;t_id++)
    {
        param[t_id].t_id=t_id;
        pthread_create(&handles[t_id],NULL,stathr_bvnew_threadfunc,&param[t_id]);
    }
    for(int t_id=0;t_id<NUM_THREADS;t_id++)
    {
        pthread_join(handles[t_id],NULL);
    }
    pthread_barrier_destroy(&barrier_stathr_elimination);
    pthread_barrier_destroy(&barrier_stathr_setzero);
    QueryPerformanceCounter((LARGE_INTEGER*)&tail);
    cout << "stathr_bvnew: " << ((tail - head) * 1000.0 / freq) << "ms" << endl;
}

//�黮��
//�̺߳���
void *stathr_bblock_threadfunc(void *param){
    sta_threadParam_t *p=(sta_threadParam_t*)param;
    int t_id=p->t_id;

    for(int k=0;k<N;k++)
    {
        //1���߳���ɳ���
        if(t_id<divthreadnum)
        {
            int blockt=((N-k-1)%NUM_THREADS)==0?((N-k-1)/NUM_THREADS):(((N-k-1)/NUM_THREADS)+1);
            for(int j=k+1+t_id*blockt;j<N&&j<k+1+(t_id+1)*blockt;j++)
            {
                mat[k][j]=mat[k][j]/mat[k][k];
            }
            mat[k][k]=1.0;
        }
        //��һ��ͬ����
        pthread_barrier_wait(&barrier_stathr_division);
        //��������
        int block=((N-k-1)%NUM_THREADS)==0?((N-k-1)/NUM_THREADS):(((N-k-1)/NUM_THREADS)+1);
        for(int i=k+1+t_id*block;i<N&&i<k+1+(t_id+1)*block;i++)
        {
            //��ȥ
            for(int j=k+1;j<N;j++)
            {
                mat[i][j]=mat[i][j]-mat[i][k]*mat[k][j];
            }
            mat[i][k]=0.0;
        }
        //�ڶ���ͬ����
        pthread_barrier_wait(&barrier_stathr_elimination);
    }
    pthread_exit(NULL);
}
void stathr_bblock()
{
    long long head, tail, freq;
    QueryPerformanceFrequency((LARGE_INTEGER*)&freq);
    QueryPerformanceCounter((LARGE_INTEGER*)&head);
    //��ʼ��barrier
    pthread_barrier_init(&barrier_stathr_division,NULL,NUM_THREADS);
    pthread_barrier_init(&barrier_stathr_elimination,NULL,NUM_THREADS);
    //�����߳�
    pthread_t handles[NUM_THREADS];
    sta_threadParam_t param[NUM_THREADS];
    for(int t_id=0;t_id<NUM_THREADS;t_id++)
    {
        param[t_id].t_id=t_id;
        pthread_create(&handles[t_id],NULL,stathr_bblock_threadfunc,&param[t_id]);
    }
    for(int t_id=0;t_id<NUM_THREADS;t_id++)
    {
        pthread_join(handles[t_id],NULL);
    }
    pthread_barrier_destroy(&barrier_stathr_division);
    pthread_barrier_destroy(&barrier_stathr_elimination);
    QueryPerformanceCounter((LARGE_INTEGER*)&tail);
    cout << "stathr_bblock: " << ((tail - head) * 1000.0 / freq) << "ms" << endl;
}

//--------------------------------------------------------AVXpthread------------------------------------------------------
//ˮƽ����+AVX
//�̺߳���
void *stathr_bhAVX_threadfunc(void *param){
    sta_threadParam_t *p=(sta_threadParam_t*)param;
    int t_id=p->t_id;

    for(int k=0;k<N;k++)
    {
        //1���߳���ɳ���
        if(t_id<divthreadnum)
        {
            float kkt[8]={mat[k][k],mat[k][k],mat[k][k],mat[k][k],mat[k][k],mat[k][k],mat[k][k],mat[k][k]};
            __m256 kk = _mm256_loadu_ps(&kkt[0]);
            int j=k+1+t_id;
            for(;j+8*divthreadnum<N;j+=8*divthreadnum)
            {
                __m256 loadone = _mm256_loadu_ps(&mat[k][j]);
                __m256 loadtwo = _mm256_div_ps(loadone,kk);
                _mm256_storeu_ps(&mat[k][j],loadtwo);
            }
            for (; j < N; j++)
            {
                mat[k][j] /= mat[k][k];
            }
            mat[k][k]=1.0;
        }
        //��һ��ͬ����
        pthread_barrier_wait(&barrier_stathr_division);
        //��������
        for(int i=k+1+t_id;i<N;i+=NUM_THREADS)
        {
            //��ȥ
            float ikt[8]={mat[i][k],mat[i][k],mat[i][k],mat[i][k],mat[i][k],mat[i][k],mat[i][k],mat[i][k]};
            __m256 ik = _mm256_loadu_ps(&ikt[0]);
            int nj=k+1;
            for(;nj+8<N;nj+=8)
            {
                __m256 loaone = _mm256_loadu_ps(&mat[i][nj]);
                __m256 loatwo = _mm256_loadu_ps(&mat[k][nj]);
                loatwo = _mm256_mul_ps(loatwo,ik);
                _mm256_storeu_ps(&mat[i][nj],_mm256_sub_ps(loaone,loatwo));
            }
            for(;nj<N;nj++)
            {
                mat[i][nj]=mat[i][nj]-mat[i][k]*mat[k][nj];
            }
            mat[i][k]=0.0;
        }
        //�ڶ���ͬ����
        pthread_barrier_wait(&barrier_stathr_elimination);
    }
    pthread_exit(NULL);
}
void stathr_bhAVX()
{
    long long head, tail, freq;
    QueryPerformanceFrequency((LARGE_INTEGER*)&freq);
    QueryPerformanceCounter((LARGE_INTEGER*)&head);
    //��ʼ��barrier
    pthread_barrier_init(&barrier_stathr_division,NULL,NUM_THREADS);
    pthread_barrier_init(&barrier_stathr_elimination,NULL,NUM_THREADS);
    //�����߳�
    pthread_t handles[NUM_THREADS];
    sta_threadParam_t param[NUM_THREADS];
    for(int t_id=0;t_id<NUM_THREADS;t_id++)
    {
        param[t_id].t_id=t_id;
        pthread_create(&handles[t_id],NULL,stathr_bhAVX_threadfunc,&param[t_id]);
    }
    for(int t_id=0;t_id<NUM_THREADS;t_id++)
    {
        pthread_join(handles[t_id],NULL);
    }
    pthread_barrier_destroy(&barrier_stathr_division);
    pthread_barrier_destroy(&barrier_stathr_elimination);
    QueryPerformanceCounter((LARGE_INTEGER*)&tail);
    cout << "stathr_bhAVX: " << ((tail - head) * 1000.0 / freq) << "ms" << endl;
}

//�黮��+AVX
//�̺߳���
void *stathr_bblockAVX_threadfunc(void *param){
    sta_threadParam_t *p=(sta_threadParam_t*)param;
    int t_id=p->t_id;

    for(int k=0;k<N;k++)
    {
        //1���߳���ɳ���
        if(t_id<divthreadnum)
        {
            int blockt=((N-k-1)%NUM_THREADS)==0?((N-k-1)/NUM_THREADS):(((N-k-1)/NUM_THREADS)+1);
            float kkt[8]={mat[k][k],mat[k][k],mat[k][k],mat[k][k],mat[k][k],mat[k][k],mat[k][k],mat[k][k]};
            __m256 kk = _mm256_loadu_ps(&kkt[0]);
            int j=k+1+t_id*blockt;
            for(;j+8<N&&j+8<k+1+(t_id+1)*blockt;j+=8)
            {
                __m256 loadone = _mm256_loadu_ps(&mat[k][j]);
                __m256 loadtwo = _mm256_div_ps(loadone,kk);
                _mm256_storeu_ps(&mat[k][j],loadtwo);
            }
            for (; j < N&&j<k+1+(t_id+1)*blockt; j++)
            {
                mat[k][j] /= mat[k][k];
            }
            mat[k][k]=1.0;
        }
        //��һ��ͬ����
        pthread_barrier_wait(&barrier_stathr_division);
        //��������
        int block=((N-k-1)%NUM_THREADS)==0?((N-k-1)/NUM_THREADS):(((N-k-1)/NUM_THREADS)+1);
        for(int i=k+1+t_id*block;i<N&&i<k+1+(t_id+1)*block;i++)
        {
            //��ȥ
            float ikt[8]={mat[i][k],mat[i][k],mat[i][k],mat[i][k],mat[i][k],mat[i][k],mat[i][k],mat[i][k]};
            __m256 ik = _mm256_loadu_ps(&ikt[0]);
            int nj=k+1;
            for(;nj+8<N;nj+=8)
            {
                __m256 loaone = _mm256_loadu_ps(&mat[i][nj]);
                __m256 loatwo = _mm256_loadu_ps(&mat[k][nj]);
                loatwo = _mm256_mul_ps(loatwo,ik);
                _mm256_storeu_ps(&mat[i][nj],_mm256_sub_ps(loaone,loatwo));
            }
            for(;nj<N;nj++)
            {
                mat[i][nj]=mat[i][nj]-mat[i][k]*mat[k][nj];
            }
            mat[i][k]=0.0;
        }
        //�ڶ���ͬ����
        pthread_barrier_wait(&barrier_stathr_elimination);
    }
    pthread_exit(NULL);
}
void stathr_bblockAVX()
{
    long long head, tail, freq;
    QueryPerformanceFrequency((LARGE_INTEGER*)&freq);
    QueryPerformanceCounter((LARGE_INTEGER*)&head);
    //��ʼ��barrier
    pthread_barrier_init(&barrier_stathr_division,NULL,NUM_THREADS);
    pthread_barrier_init(&barrier_stathr_elimination,NULL,NUM_THREADS);
    //�����߳�
    pthread_t handles[NUM_THREADS];
    sta_threadParam_t param[NUM_THREADS];
    for(int t_id=0;t_id<NUM_THREADS;t_id++)
    {
        param[t_id].t_id=t_id;
        pthread_create(&handles[t_id],NULL,stathr_bblockAVX_threadfunc,&param[t_id]);
    }
    for(int t_id=0;t_id<NUM_THREADS;t_id++)
    {
        pthread_join(handles[t_id],NULL);
    }
    pthread_barrier_destroy(&barrier_stathr_division);
    pthread_barrier_destroy(&barrier_stathr_elimination);
    QueryPerformanceCounter((LARGE_INTEGER*)&tail);
    cout << "stathr_bblockAVX: " << ((tail - head) * 1000.0 / freq) << "ms" << endl;
}

int main()
{
    for(int a=0;a<1;a++)
    {
//    init();
//    trivial();
//    print();
//    init();
//    AVX();
//    print();
//    init();
//    dynamic();
//    print();
//    init();
//    statwo();
//    print();
    init();
    stathr();
//    print();
    init();
    stathr_bh();
//    print();
//    init();
//    stathr_bv();
//    print();
//    init();
//    stathr_bvnew();
//    print();
    init();
    stathr_bblock();
//    print();
//    init();
//    stathr_bhAVX();
//    print();
//    init();
//    stathr_bblockAVX();
//    print();
cout<<endl;
    }

    return 0;
}
