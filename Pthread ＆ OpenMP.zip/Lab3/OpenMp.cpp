#include <iostream>
#include<immintrin.h>
#include<Windows.h>
#include <omp.h>

using namespace std;

const int N = 1000;
float mat[N][N];
float B[N];
float X[N];
const int NUM_THREADS=4;

//��ʼ��   //Ϊ��ֹ����nan�Գ�ʼ�����иĽ�������ܷ��ָ�ֵ�������Ǿ����ֵ����ȥ����ͬ
void init()
{
    srand(static_cast <unsigned> (1));
    for(int a=0;a<N;a++)
    {
        mat[a][a]=1.0;
        B[a]=(float)rand();
        X[a]=0;
        for(int b=a+1;b<N;b++)//��ʼ�������Ǿ���Ϊ�����
        {
            mat[a][b]=rand()%100;
        }
        for(int b=0;b<a;b++)//�����Ǿ���Ϊ0
        {
            mat[a][b]=0;
        }
    }
    for(int a=1;a<N;a++)//���ڼӷ�����
    {
       for(int b=0;b<N;b++)
       {
           mat[a][b]+=mat[a-1][b];
       }
    }
}
//��֤��ȷ
void print()
{
    for(int a=0;a<N;a++)
    {
        cout<<mat[67][a]<<" ";
    }
    cout<<endl;
}

//--------------------------------------------------------ƽ������------------------------------------------------------
//ƽ������ȫ����
void triviallast()
{
//��ȥ
    for(int k=0;k<N;k++)
    {
        for(int i=k+1;i<N;i++)
        {
            float factor=mat[i][k]/mat[k][k];
            for(int j=k+1;j<N;j++)
            {
                mat[i][j]-=factor*mat[k][j];
            }
            B[i]-=factor*B[k];
        }
    }
//�ش�
    for(int i=N-2;i>=0;i--)
    {
        float sum=B[i];
        for(int j=i+1;j<N;j++)
        {
            sum-=mat[i][j]*X[j];
        }
        X[i]=sum/mat[i][i];
    }
}
//ƽ��������ȥ���֣��Ż�����
void trivial()
{
    long long head, tail, freq;
	QueryPerformanceFrequency((LARGE_INTEGER*)&freq);
	QueryPerformanceCounter((LARGE_INTEGER*)&head);
    for(int k=0;k<N;k++)
    {
        for(int j=k+1;j<N;j++)
        {
            mat[k][j]/=mat[k][k];
        }
        mat[k][k]=1.0;

        for(int i=k+1;i<N;i++)
        {
            for(int j=k+1;j<N;j++)
            {
                mat[i][j]-=mat[i][k]*mat[k][j];
            }
            mat[i][k]=0;
        }
    }
    QueryPerformanceCounter((LARGE_INTEGER*)&tail);
    cout << "trivial: " << ((tail - head) * 1000.0 / freq) << "ms" << endl;
}

//--------------------------------------------------------AVX------------------------------------------------------
void AVX()
{
    long long head, tail, freq;
	QueryPerformanceFrequency((LARGE_INTEGER*)&freq);
	QueryPerformanceCounter((LARGE_INTEGER*)&head);
    for(int k=0;k<N;k++)
    {
        float kkt[8]={mat[k][k],mat[k][k],mat[k][k],mat[k][k],mat[k][k],mat[k][k],mat[k][k],mat[k][k]};
        __m256 kk = _mm256_loadu_ps(&kkt[0]);
        int j=k+1;
        for(;j+8<N;j+=8)
        {
            __m256 loadone = _mm256_loadu_ps(&mat[k][j]);
            __m256 loadtwo = _mm256_div_ps(loadone,kk);
            _mm256_storeu_ps(&mat[k][j],loadtwo);
        }
        for (; j < N; j++)
        {
            mat[k][j] /= mat[k][k];
        }
        mat[k][k]=1.0;

        for(int i=k+1;i<N;i++)
        {
            float ikt[8]={mat[i][k],mat[i][k],mat[i][k],mat[i][k],mat[i][k],mat[i][k],mat[i][k],mat[i][k]};
            __m256 ik = _mm256_loadu_ps(&ikt[0]);
            int nj=k+1;
            for(;nj+8<N;nj+=8)
            {
                __m256 loaone = _mm256_loadu_ps(&mat[i][nj]);
                __m256 loatwo = _mm256_loadu_ps(&mat[k][nj]);
                loatwo = _mm256_mul_ps(loatwo,ik);
                _mm256_storeu_ps(&mat[i][nj],_mm256_sub_ps(loaone,loatwo));
            }
            for(;nj<N;nj++)
            {
                mat[i][nj]-=mat[i][k]*mat[k][nj];
            }
            mat[i][k]=0;
        }
    }
    QueryPerformanceCounter((LARGE_INTEGER*)&tail);
    cout << "AVX: " << ((tail - head) * 1000.0 / freq) << "ms" << endl;
}

//--------------------------------------------------------OpenMp------------------------------------------------------

//�̴߳���λ��(��̬��-------------------------------
//��ѭ���ⴴ���߳�
void OpenMp_out()
{
    long long head, tail, freq;
	QueryPerformanceFrequency((LARGE_INTEGER*)&freq);
	QueryPerformanceCounter((LARGE_INTEGER*)&head);
    int i,j,k;
    float tmp;
    //����ѭ��֮�ⴴ���߳�
#pragma omp parallel num_threads(NUM_THREADS) default(none) shared(mat,N) private(i,j,k,tmp)
    for(k=0;k<N;k++)
    {
        //���в��֣�Ҳ���Գ��Բ��л�
        tmp=mat[k][k];
#pragma omp for
        for(j=k+1;j<N;j++)
        {
            mat[k][j]=mat[k][j]/tmp;
        }
        mat[k][k]=1.0;
        //���в��֣�ʹ���л���
#pragma omp for
        for(i=k+1;i<N;i++)
        {
            tmp =mat[i][k];
            for(j=k+1;j<N;j++)
            {
                mat[i][j]=mat[i][j]-tmp*mat[k][j];
            }
            mat[i][k]=0.0;
        }
    }
    //�뿪forѭ��ʱ�������߳�Ĭ��ͬ��
    QueryPerformanceCounter((LARGE_INTEGER*)&tail);
    cout << "OpenMp_out: " << ((tail - head) * 1000.0 / freq) << "ms" << endl;
}
//��ѭ���ڴ���
void OpenMp_in()
{
    long long head, tail, freq;
	QueryPerformanceFrequency((LARGE_INTEGER*)&freq);
	QueryPerformanceCounter((LARGE_INTEGER*)&head);
    int i,j;
    int k=0;
    float tmp;
    //����ѭ��֮�ⴴ���߳�
    for(k=0;k<N;k++)
    {
        //���в��֣�Ҳ���Գ��Բ��л�
#pragma omp parallel for num_threads(NUM_THREADS) default(none) shared(mat,N,k) private(j)
        for(j=k+1;j<N;j++)
        {
            mat[k][j]=mat[k][j]/mat[k][k];
        }
        mat[k][k]=1.0;
        //���в��֣�ʹ���л���
#pragma omp parallel for num_threads(NUM_THREADS) default(none) shared(mat,N,k) private(i,j,tmp)
        for(i=k+1;i<N;i++)
        {
            tmp =mat[i][k];
            for(j=k+1;j<N;j++)
            {
                mat[i][j]=mat[i][j]-tmp*mat[k][j];
            }
            mat[i][k]=0.0;
        }
    }
    //�뿪forѭ��ʱ�������߳�Ĭ��ͬ��
    QueryPerformanceCounter((LARGE_INTEGER*)&tail);
    cout << "OpenMp_in: " << ((tail - head) * 1000.0 / freq) << "ms" << endl;
}

//�������л���-------------------------------
//�л���
void OpenMp_h()
{
    long long head, tail, freq;
	QueryPerformanceFrequency((LARGE_INTEGER*)&freq);
	QueryPerformanceCounter((LARGE_INTEGER*)&head);
    int i,j,k;
    float tmp;
    //����ѭ��֮�ⴴ���߳�
#pragma omp parallel num_threads(NUM_THREADS) default(none) shared(mat,N) private(i,j,k,tmp)
    for(k=0;k<N;k++)
    {
        //���в��֣�Ҳ���Գ��Բ��л�
#pragma omp single
        {
            tmp=mat[k][k];
            for(j=k+1;j<N;j++)
            {
                mat[k][j]=mat[k][j]/tmp;
            }
            mat[k][k]=1.0;
        }
        //���в��֣�ʹ���л���
#pragma omp for
        for(i=k+1;i<N;i++)
        {
            tmp =mat[i][k];
            for(j=k+1;j<N;j++)
            {
                mat[i][j]=mat[i][j]-tmp*mat[k][j];
            }
            mat[i][k]=0.0;
        }
    }
    //�뿪forѭ��ʱ�������߳�Ĭ��ͬ��
    QueryPerformanceCounter((LARGE_INTEGER*)&tail);
    cout << "OpenMp_h: " << ((tail - head) * 1000.0 / freq) << "ms" << endl;
}
//�л���
void OpenMp_v()
{
    long long head, tail, freq;
	QueryPerformanceFrequency((LARGE_INTEGER*)&freq);
	QueryPerformanceCounter((LARGE_INTEGER*)&head);
    int i,j,k;
    //����ѭ��֮�ⴴ���߳�
#pragma omp parallel num_threads(NUM_THREADS) default(none) shared(mat,N) private(i,j,k)
    for(k=0;k<N;k++)
    {
        //���в��֣�ʹ���л���
#pragma omp for
        for(j=k+1;j<N;j++)
        {
            mat[k][j]=mat[k][j]/mat[k][k];
            for(i=k+1;i<N;i++)
            {
                mat[i][j]=mat[i][j]-mat[i][k]*mat[k][j];
            }
        }
        mat[k][k]=1.0;
#pragma omp single
        for(i=k+1;i<N;i++)
        {
            mat[i][k]=0.0;
        }
    }
    //�뿪forѭ��ʱ�������߳�Ĭ��ͬ��
    QueryPerformanceCounter((LARGE_INTEGER*)&tail);
    cout << "OpenMp_v: " << ((tail - head) * 1000.0 / freq) << "ms" << endl;
}

//�̼߳仮��-------------------------------
//��̬����
void OpenMp_sta()
{
    long long head, tail, freq;
	QueryPerformanceFrequency((LARGE_INTEGER*)&freq);
	QueryPerformanceCounter((LARGE_INTEGER*)&head);
    int i,j,k;
    float tmp;
    //����ѭ��֮�ⴴ���߳�
#pragma omp parallel num_threads(NUM_THREADS) default(none) shared(mat,N) private(i,j,k,tmp)
    for(k=0;k<N;k++)
    {
        //���в��֣�Ҳ���Գ��Բ��л�
#pragma omp single
        {
            tmp=mat[k][k];
            for(j=k+1;j<N;j++)
            {
                mat[k][j]=mat[k][j]/tmp;
            }
            mat[k][k]=1.0;
        }
        //���в��֣�ʹ���л���
#pragma omp for
        for(i=k+1;i<N;i++)
        {
            tmp =mat[i][k];
            for(j=k+1;j<N;j++)
            {
                mat[i][j]=mat[i][j]-tmp*mat[k][j];
            }
            mat[i][k]=0.0;
        }
    }
    //�뿪forѭ��ʱ�������߳�Ĭ��ͬ��
    QueryPerformanceCounter((LARGE_INTEGER*)&tail);
    cout << "OpenMp_sta: " << ((tail - head) * 1000.0 / freq) << "ms" << endl;
}
//��̬����(����chunk���ԣ�
const int chunk=60;
void OpenMp_dyn()
{
    long long head, tail, freq;
	QueryPerformanceFrequency((LARGE_INTEGER*)&freq);
	QueryPerformanceCounter((LARGE_INTEGER*)&head);
    int i,j,k;
    float tmp;
    //����ѭ��֮�ⴴ���߳�
#pragma omp parallel num_threads(NUM_THREADS) default(none) shared(mat,N) private(i,j,k,tmp)
    for(k=0;k<N;k++)
    {
        //���в��֣�Ҳ���Գ��Բ��л�
#pragma omp single
        {
            tmp=mat[k][k];
            for(j=k+1;j<N;j++)
            {
                mat[k][j]=mat[k][j]/tmp;
            }
            mat[k][k]=1.0;
        }
        //���в��֣�ʹ���л���
#pragma omp for schedule(dynamic)
        for(i=k+1;i<N;i++)
        {
            tmp =mat[i][k];
            for(j=k+1;j<N;j++)
            {
                mat[i][j]=mat[i][j]-tmp*mat[k][j];
            }
            mat[i][k]=0.0;
        }
    }
    //�뿪forѭ��ʱ�������߳�Ĭ��ͬ��
    QueryPerformanceCounter((LARGE_INTEGER*)&tail);
    cout << "OpenMp_dyn: " << ((tail - head) * 1000.0 / freq) << "ms" << endl;
}
//guided��̬����(����chunk���ԣ�
void OpenMp_gui()
{
    long long head, tail, freq;
	QueryPerformanceFrequency((LARGE_INTEGER*)&freq);
	QueryPerformanceCounter((LARGE_INTEGER*)&head);
    int i,j,k;
    float tmp;
    //����ѭ��֮�ⴴ���߳�
#pragma omp parallel num_threads(NUM_THREADS) default(none) shared(mat,N) private(i,j,k,tmp)
    for(k=0;k<N;k++)
    {
        //���в��֣�Ҳ���Գ��Բ��л�
#pragma omp single
        {
            tmp=mat[k][k];
            for(j=k+1;j<N;j++)
            {
                mat[k][j]=mat[k][j]/tmp;
            }
            mat[k][k]=1.0;
        }
        //���в��֣�ʹ���л���
#pragma omp for schedule(guided)
        for(i=k+1;i<N;i++)
        {
            tmp =mat[i][k];
            for(j=k+1;j<N;j++)
            {
                mat[i][j]=mat[i][j]-tmp*mat[k][j];
            }
            mat[i][k]=0.0;
        }
    }
    //�뿪forѭ��ʱ�������߳�Ĭ��ͬ��
    QueryPerformanceCounter((LARGE_INTEGER*)&tail);
    cout << "OpenMp_gui: " << ((tail - head) * 1000.0 / freq) << "ms" << endl;
}

//--------------------------------------------------------OpenMpSIMD------------------------------------------------------
//��ͨ
void OpenMp_tri()
{
    long long head, tail, freq;
	QueryPerformanceFrequency((LARGE_INTEGER*)&freq);
	QueryPerformanceCounter((LARGE_INTEGER*)&head);
    int i,j,k;
    float tmp;
    //����ѭ��֮�ⴴ���߳�
#pragma omp parallel num_threads(NUM_THREADS) default(none) shared(mat,N) private(i,j,k,tmp)
    for(k=0;k<N;k++)
    {
        //���в��֣�Ҳ���Գ��Բ��л�
#pragma omp single
        {
            tmp=mat[k][k];
            for(j=k+1;j<N;j++)
            {
                mat[k][j]=mat[k][j]/tmp;
            }
            mat[k][k]=1.0;
        }
        //���в��֣�ʹ���л���
#pragma omp for schedule(guided)
        for(i=k+1;i<N;i++)
        {
            tmp =mat[i][k];
            for(j=k+1;j<N;j++)
            {
                mat[i][j]=mat[i][j]-tmp*mat[k][j];
            }
            mat[i][k]=0.0;
        }
    }
    //�뿪forѭ��ʱ�������߳�Ĭ��ͬ��
    QueryPerformanceCounter((LARGE_INTEGER*)&tail);
    cout << "OpenMp_tri: " << ((tail - head) * 1000.0 / freq) << "ms" << endl;
}
//AVX
void OpenMp_AVX()
{
    long long head, tail, freq;
	QueryPerformanceFrequency((LARGE_INTEGER*)&freq);
	QueryPerformanceCounter((LARGE_INTEGER*)&head);
    int i,j,k;
    //����ѭ��֮�ⴴ���߳�
#pragma omp parallel num_threads(NUM_THREADS) default(none) shared(mat,N) private(i,j,k)
    for(k=0;k<N;k++)
    {
        //���в��֣�Ҳ���Գ��Բ��л�
#pragma omp single
        {
            float kkt[8]={mat[k][k],mat[k][k],mat[k][k],mat[k][k],mat[k][k],mat[k][k],mat[k][k],mat[k][k]};
            __m256 kk = _mm256_loadu_ps(&kkt[0]);
            j=k+1;
            for(;j+8<N;j+=8)
            {
                __m256 loadone = _mm256_loadu_ps(&mat[k][j]);
                __m256 loadtwo = _mm256_div_ps(loadone,kk);
                _mm256_storeu_ps(&mat[k][j],loadtwo);
            }
            for (; j < N; j++)
            {
                mat[k][j] /= mat[k][k];
            }
            mat[k][k]=1.0;
        }
        //���в��֣�ʹ���л���
#pragma omp for schedule(guided)
        for(i=k+1;i<N;i++)
        {

            float ikt[8]={mat[i][k],mat[i][k],mat[i][k],mat[i][k],mat[i][k],mat[i][k],mat[i][k],mat[i][k]};
            __m256 ik = _mm256_loadu_ps(&ikt[0]);
            j=k+1;
            for(;j+8<N;j+=8)
            {
                __m256 loaone = _mm256_loadu_ps(&mat[i][j]);
                __m256 loatwo = _mm256_loadu_ps(&mat[k][j]);
                loatwo = _mm256_mul_ps(loatwo,ik);
                _mm256_storeu_ps(&mat[i][j],_mm256_sub_ps(loaone,loatwo));
            }
            for(;j<N;j++)
            {
                mat[i][j]-=mat[i][k]*mat[k][j];
            }
            mat[i][k]=0.0;
        }
    }
    //�뿪forѭ��ʱ�������߳�Ĭ��ͬ��
    QueryPerformanceCounter((LARGE_INTEGER*)&tail);
    cout << "OpenMp_AVX: " << ((tail - head) * 1000.0 / freq) << "ms" << endl;
}
//OpenMp��������
void OpenMp_simd()
{
    long long head, tail, freq;
	QueryPerformanceFrequency((LARGE_INTEGER*)&freq);
	QueryPerformanceCounter((LARGE_INTEGER*)&head);
    int i,j,k;
    float tmp;
    //����ѭ��֮�ⴴ���߳�
#pragma omp parallel num_threads(NUM_THREADS) default(none) shared(mat,N) private(i,j,k,tmp)
    for(k=0;k<N;k++)
    {
        //���в��֣�Ҳ���Գ��Բ��л�
#pragma omp single
        {
            tmp=mat[k][k];
    #pragma omp simd simdlen(8) safelen(N)
            for(j=k+1;j<N;j++)
            {
                mat[k][j]=mat[k][j]/tmp;
            }
            mat[k][k]=1.0;
        }
        //���в��֣�ʹ���л���
#pragma omp for schedule(guided)
        for(i=k+1;i<N;i++)
        {
            tmp =mat[i][k];
    #pragma omp simd simdlen(8) safelen(N)
            for(j=k+1;j<N;j++)
            {
                mat[i][j]=mat[i][j]-tmp*mat[k][j];
            }
            mat[i][k]=0.0;
        }
    }
    //�뿪forѭ��ʱ�������߳�Ĭ��ͬ��
    QueryPerformanceCounter((LARGE_INTEGER*)&tail);
    cout << "OpenMp_simd: " << ((tail - head) * 1000.0 / freq) << "ms" << endl;
}

int main()
{
    for(int a=0;a<1;a++)
    {
    init();
    trivial();
//    print();
//    init();
//    AVX();
//    print();
//    init();
//    OpenMp_out();
//    print();
//    init();
//    OpenMp_in();
//    print();
    init();
    OpenMp_h();
//    print();
//    init();
//    OpenMp_v();
//    print();
//    init();
//    OpenMp_sta();
//    print();
//    init();
//    OpenMp_dyn();
//    print();
//    init();
//    OpenMp_gui();
//    print();
//    init();
//    OpenMp_tri();
//    print();
    init();
    OpenMp_AVX();
//    print();
    init();
    OpenMp_simd();
//    print();
cout<<endl;
    }

    return 0;
}
