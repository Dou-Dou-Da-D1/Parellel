#include <iostream>
#include<cstdlib>
#include<stdlib.h>
#include<pthread.h>
#include<immintrin.h>
#include<Windows.h>
#include<semaphore.h>
#include<fstream>
#include<string>
#include<sstream>
using namespace std;

const int N=3799;//����
const int elimN=2759;//������Ԫ��
const int elimedN=1953;//����Ԫ��
string path1="D:\Groebner\��������6 ��������3799��������Ԫ��2759������Ԫ��1953\��Ԫ��.txt";
string path2="D:\Groebner\��������6 ��������3799��������Ԫ��2759������Ԫ��1953\����Ԫ��.txt";

int elim[N][N+1]={0};
int elimed[elimedN][N+1]={0};

void print()
{
    for(int a=0;a<N;a++)
    {
        cout<<elim[2][a]<<" ";
    }
    cout<<endl;
    for(int a=0;a<N;a++)
    {
        cout<<elim[4][a]<<" ";
    }
    cout<<endl;
}

//��ʼ����Ԫ��
void init_elim()
{
    ifstream infile(path1);
    //��ȡ��
    int index=0;
    string strline;
    while(getline(infile,strline))//������һ��
    {
        bool flag=true;
        istringstream in(strline);
        string tempstr;
        int tempint=0;
        while(in >> tempstr)
        {
            istringstream str_int(tempstr);
            str_int >> tempint;
            if(flag)
            {
                flag=false;
                index=tempint;
            }
            elim[index][N-1-tempint]=1;
            elim[index][N]=1;//��Ϊ��
        }
    }
}
//��ʼ������Ԫ��
void init_beelimed()
{
    ifstream infile(path2);
    //��ȡ��
    int index=0;
    string strline;
    while(getline(infile,strline))//������һ��
    {
        bool flag=true;
        istringstream in(strline);
        string tempstr;
        int tempint=0;
        while(in >> tempstr)
        {
            istringstream str_int(tempstr);
            str_int >> tempint;
            if(flag)
            {
                flag=false;
                elimed[index][N]=tempint;//��һ��1��λ��
            }
            elimed[index][N-1-tempint]=1;
        }
        index++;
    }
}
//ƽ������
void trivial()
{
    long long head, tail, freq;
	QueryPerformanceFrequency((LARGE_INTEGER*)&freq);
	QueryPerformanceCounter((LARGE_INTEGER*)&head);
    bool flag=true;
    while(flag)
    {
        for(int i=N-1;i-8>=0;i-=8)//һ�ִ���8����Ԫ��
        {
            for(int j=0;j<elimedN;j++)//��鱻��Ԫ��
            {
                while(elimed[j][N]>=i-7&&elimed[j][N]<=i)//����Ԫ
                {
                    int elim_index=elimed[j][N];
                    if(elim[elim_index][N]!=0)//�п�����Ԫ��
                    {
                        for(int k=0;k<N;k++)//��Ԫ
                        {
                            elimed[j][k]=elimed[j][k]^elim[elim_index][k];
                        }
                        bool ifnull=true;
                        for(int a=0;a<N;a++)//ˢ�¼�¼�ĵ�һ��1λ��
                        {
                            if(elimed[j][a]==1)
                            {
                                elimed[j][N]=N-a-1;
                                ifnull=false;
                                break;
                            }
                        }
                        if(ifnull)
                        {
                            elimed[j][N]=-1;
                        }
                    }
                    else
                    {
                        break;
                    }
                }
            }
        }
        for(int i = N%8-1;i>=0;i--)//����ʣ�µ���Ԫ��
        {
            for(int j=0;j<elimedN;j++)//��鱻��Ԫ��
            {
                while(elimed[j][N]==i)//����Ԫ
                {
                    int elim_index=elimed[j][N];
                    if(elim[elim_index][N]!=0)//�п�����Ԫ��
                    {
                        for(int k=0;k<N;k++)//��Ԫ
                        {
                            elimed[j][k]=elimed[j][k]^elim[elim_index][k];
                        }
                        bool ifnull=true;
                        for(int a=0;a<N;a++)//ˢ�¼�¼�ĵ�һ��1λ��
                        {
                            if(elimed[j][a]==1)
                            {
                                elimed[j][N]=N-a-1;
                                ifnull=false;
                                break;
                            }
                        }
                        if(ifnull)
                        {
                            elimed[j][N]=-1;
                        }
                    }
                    else
                    {
                        break;
                    }
                }
            }
        }
        flag=false;
        for(int i=0;i<elimedN;i++)//����Ƿ��������
        {
            if((elimed[i][N]!=-1)&&(elim[elimed[i][N]][N]==0))//����
            {
                for(int k=0;k<N;k++)
                {
                    elim[elimed[i][N]][k]=elimed[i][k];
                }
                elimed[i][N]=-1;
                flag=true;
            }
        }
    }
    QueryPerformanceCounter((LARGE_INTEGER*)&tail);
    cout << "trivial: " << ((tail - head) * 1000.0 / freq) << "ms" << endl;
}

//----------------------------------------------------�Ż�AVX--------------------------------------------------
void AVX()
{
    long long head, tail, freq;
	QueryPerformanceFrequency((LARGE_INTEGER*)&freq);
	QueryPerformanceCounter((LARGE_INTEGER*)&head);
    bool flag=true;
    while(flag)
    {
        for(int i=N-1;i-8>=0;i-=8)//һ�ִ���8����Ԫ��
        {
            for(int j=0;j<elimedN;j++)//��鱻��Ԫ��
            {
                while(elimed[j][N]>=i-7&&elimed[j][N]<=i)//����Ԫ
                {
                    int elim_index=elimed[j][N];
                    if(elim[elim_index][N]!=0)//�п�����Ԫ��
                    {
                        int k=0;
                        for(;k+8<N;k+=8)//��Ԫ
                        {
                            __m256i loadone = _mm256_loadu_si256((__m256i*)&elimed[j][k]);
                            __m256i loadtwo = _mm256_loadu_si256((__m256i*)&elimed[elim_index][k]);
                            _mm256_storeu_si256((__m256i*)&elimed[j][k],_mm256_mul_epi32(loadone,loadtwo));
                        }
                        for(;k<N;k++)//��Ԫ
                        {
                            elimed[j][k]=elimed[j][k]^elim[elim_index][k];
                        }
                        bool ifnull=true;
                        for(int a=0;a<N;a++)//ˢ�¼�¼�ĵ�һ��1λ��
                        {
                            if(elimed[j][a]==1)
                            {
                                elimed[j][N]=N-a-1;
                                ifnull=false;
                                break;
                            }
                        }
                        if(ifnull)
                        {
                            elimed[j][N]=-1;
                        }
                    }
                    else
                    {
                        break;
                    }
                }
            }
        }
        for(int i = N%8-1;i>=0;i--)//����ʣ�µ���Ԫ��
        {
            for(int j=0;j<elimedN;j++)//��鱻��Ԫ��
            {
                while(elimed[j][N]==i)//����Ԫ
                {
                    int elim_index=elimed[j][N];
                    if(elim[elim_index][N]!=0)//�п�����Ԫ��
                    {
                        int k=0;
                        for(;k+8<N;k+=8)//��Ԫ
                        {
                            __m256i loadone = _mm256_loadu_si256((__m256i*)&elimed[j][k]);
                            __m256i loadtwo = _mm256_loadu_si256((__m256i*)&elimed[elim_index][k]);
                            _mm256_storeu_si256((__m256i*)&elimed[j][k],_mm256_mul_epi32(loadone,loadtwo));
                        }
                        for(;k<N;k++)//��Ԫ
                        {
                            elimed[j][k]=elimed[j][k]^elim[elim_index][k];
                        }
                        bool ifnull=true;
                        for(int a=0;a<N;a++)//ˢ�¼�¼�ĵ�һ��1λ��
                        {
                            if(elimed[j][a]==1)
                            {
                                elimed[j][N]=N-a-1;
                                ifnull=false;
                                break;
                            }
                        }
                        if(ifnull)
                        {
                            elimed[j][N]=-1;
                        }
                    }
                    else
                    {
                        break;
                    }
                }
            }
        }
        flag=false;
        for(int i=0;i<elimedN;i++)//����Ƿ��������
        {
            if((elimed[i][N]!=-1)&&(elim[elimed[i][N]][N]==0))//����
            {
                int k=0;
                for(;k+8<N;k+=8)
                {
                    __m256i loadone = _mm256_loadu_si256((__m256i*)&elimed[i][k]);
                    _mm256_storeu_si256((__m256i*)&elim[elimed[i][N]][k],loadone);
                }
                for(;k<N;k++)
                {
                    elim[elimed[i][N]][k]=elimed[i][k];
                }
                elimed[i][N]=-1;
                flag=true;
            }
        }
    }
    QueryPerformanceCounter((LARGE_INTEGER*)&tail);
    cout << "AVX: " << ((tail - head) * 1000.0 / freq) << "ms" << endl;
}

//----------------------------------------------------�Ż����߳�--------------------------------------------------
const int NUM_THREADS=4;
//barrier����
pthread_barrier_t barrier_eliminate;
pthread_barrier_t barrier_upgrade;
//�̶߳���
typedef struct{
   int t_id;//�߳�id
}threadParam_t;

//�̺߳���
void *threadfunc(void *param)
{
    threadParam_t *p=(threadParam_t*)param;
    int t_id=p->t_id;
    bool flag=true;
    while(flag)
    {
        for(int i=N-1;i-8>=0;i-=8)//һ�ִ���8����Ԫ��
        {
            for(int j=t_id;j<elimedN;j+=NUM_THREADS)//��鱻��Ԫ��
            {
                while(elimed[j][N]>=i-7&&elimed[j][N]<=i)//����Ԫ
                {
                    int elim_index=elimed[j][N];
                    if(elim[elim_index][N]!=0)//�п�����Ԫ��
                    {
                        for(int k=0;k<N;k++)//��Ԫ
                        {
                            elimed[j][k]=elimed[j][k]^elim[elim_index][k];
                        }
                        bool ifnull=true;
                        for(int a=0;a<N;a++)//ˢ�¼�¼�ĵ�һ��1λ��
                        {
                            if(elimed[j][a]==1)
                            {
                                elimed[j][N]=N-a-1;
                                ifnull=false;
                                break;
                            }
                        }
                        if(ifnull)
                        {
                            elimed[j][N]=-1;
                        }
                    }
                    else
                    {
                        break;
                    }
                }
            }
        }
        for(int i = N%8-1;i>=0;i--)//����ʣ�µ���Ԫ��
        {
            for(int j=t_id;j<elimedN;j+=NUM_THREADS)//��鱻��Ԫ��
            {
                while(elimed[j][N]==i)//����Ԫ
                {
                    int elim_index=elimed[j][N];
                    if(elim[elim_index][N]!=0)//�п�����Ԫ��
                    {
                        for(int k=0;k<N;k++)//��Ԫ
                        {
                            elimed[j][k]=elimed[j][k]^elim[elim_index][k];
                        }
                        bool ifnull=true;
                        for(int a=0;a<N;a++)//ˢ�¼�¼�ĵ�һ��1λ��
                        {
                            if(elimed[j][a]==1)
                            {
                                elimed[j][N]=N-a-1;
                                ifnull=false;
                                break;
                            }
                        }
                        if(ifnull)
                        {
                            elimed[j][N]=-1;
                        }
                    }
                    else
                    {
                        break;
                    }
                }
            }
        }
        //��һ��ͬ����
        pthread_barrier_wait(&barrier_eliminate);
        flag=false;
        for(int i=t_id;i<elimedN;i+=NUM_THREADS)//����Ƿ��������
        {
            if((elimed[i][N]!=-1)&&(elim[elimed[i][N]][N]==0))//����
            {
                for(int k=0;k<N;k++)
                {
                    elim[elimed[i][N]][k]=elimed[i][k];
                }
                elimed[i][N]=-1;
                flag=true;
            }
        }
        //�ڶ���ͬ����
        pthread_barrier_wait(&barrier_upgrade);
    }
}
void pthread()
{
    long long head, tail, freq;
    QueryPerformanceFrequency((LARGE_INTEGER*)&freq);
    QueryPerformanceCounter((LARGE_INTEGER*)&head);
    //��ʼ��barrier
    pthread_barrier_init(&barrier_eliminate,NULL,NUM_THREADS);
    pthread_barrier_init(&barrier_upgrade,NULL,NUM_THREADS);
    //�����߳�
    pthread_t handles[NUM_THREADS];
    threadParam_t param[NUM_THREADS];
    for(int t_id=0;t_id<NUM_THREADS;t_id++)
    {
        param[t_id].t_id=t_id;
        pthread_create(&handles[t_id],NULL,threadfunc,&param[t_id]);
    }
    for(int t_id=0;t_id<NUM_THREADS;t_id++)
    {
        pthread_join(handles[t_id],NULL);
    }
    pthread_barrier_destroy(&barrier_eliminate);
    pthread_barrier_destroy(&barrier_upgrade);
    QueryPerformanceCounter((LARGE_INTEGER*)&tail);
    cout << "pthread: " << ((tail - head) * 1000.0 / freq) << "ms" << endl;
}

//----------------------------------------------------�Ż����߳�+AVX--------------------------------------------------
//�̺߳���
void *threadfuncAVX(void *param)
{
    threadParam_t *p=(threadParam_t*)param;
    int t_id=p->t_id;
    bool flag=true;
    while(flag)
    {
        for(int i=N-1;i-8>=0;i-=8)//һ�ִ���8����Ԫ��
        {
            for(int j=t_id;j<elimedN;j+=NUM_THREADS)//��鱻��Ԫ��
            {
                while(elimed[j][N]>=i-7&&elimed[j][N]<=i)//����Ԫ
                {
                    int elim_index=elimed[j][N];
                    if(elim[elim_index][N]!=0)//�п�����Ԫ��
                    {
                        int k=0;
                        for(;k+8<N;k+=8)//��Ԫ
                        {
                            __m256i loadone = _mm256_loadu_si256((__m256i*)&elimed[j][k]);
                            __m256i loadtwo = _mm256_loadu_si256((__m256i*)&elimed[elim_index][k]);
                            _mm256_storeu_si256((__m256i*)&elimed[j][k],_mm256_mul_epi32(loadone,loadtwo));
                        }
                        for(;k<N;k++)//��Ԫ
                        {
                            elimed[j][k]=elimed[j][k]^elim[elim_index][k];
                        }
                        bool ifnull=true;
                        for(int a=0;a<N;a++)//ˢ�¼�¼�ĵ�һ��1λ��
                        {
                            if(elimed[j][a]==1)
                            {
                                elimed[j][N]=N-a-1;
                                ifnull=false;
                                break;
                            }
                        }
                        if(ifnull)
                        {
                            elimed[j][N]=-1;
                        }
                    }
                    else
                    {
                        break;
                    }
                }
            }
        }
        for(int i = N%8-1;i>=0;i--)//����ʣ�µ���Ԫ��
        {
            for(int j=t_id;j<elimedN;j+=NUM_THREADS)//��鱻��Ԫ��
            {
                while(elimed[j][N]==i)//����Ԫ
                {
                    int elim_index=elimed[j][N];
                    if(elim[elim_index][N]!=0)//�п�����Ԫ��
                    {
                        int k=0;
                        for(;k+8<N;k+=8)//��Ԫ
                        {
                            __m256i loadone = _mm256_loadu_si256((__m256i*)&elimed[j][k]);
                            __m256i loadtwo = _mm256_loadu_si256((__m256i*)&elimed[elim_index][k]);
                            _mm256_storeu_si256((__m256i*)&elimed[j][k],_mm256_mul_epi32(loadone,loadtwo));
                        }
                        for(;k<N;k++)//��Ԫ
                        {
                            elimed[j][k]=elimed[j][k]^elim[elim_index][k];
                        }
                        bool ifnull=true;
                        for(int a=0;a<N;a++)//ˢ�¼�¼�ĵ�һ��1λ��
                        {
                            if(elimed[j][a]==1)
                            {
                                elimed[j][N]=N-a-1;
                                ifnull=false;
                                break;
                            }
                        }
                        if(ifnull)
                        {
                            elimed[j][N]=-1;
                        }
                    }
                    else
                    {
                        break;
                    }
                }
            }
        }
        //��һ��ͬ����
        pthread_barrier_wait(&barrier_eliminate);
        flag=false;
        for(int i=t_id;i<elimedN;i+=NUM_THREADS)//����Ƿ��������
        {
            if((elimed[i][N]!=-1)&&(elim[elimed[i][N]][N]==0))//����
            {
                int k=0;
                for(;k+8<N;k+=8)
                {
                    __m256i loadone = _mm256_loadu_si256((__m256i*)&elimed[i][k]);
                    _mm256_storeu_si256((__m256i*)&elim[elimed[i][N]][k],loadone);
                }
                for(;k<N;k++)
                {
                    elim[elimed[i][N]][k]=elimed[i][k];
                }
                elimed[i][N]=-1;
                flag=true;
            }
        }
        //�ڶ���ͬ����
        pthread_barrier_wait(&barrier_upgrade);
    }
}
void pthreadAVX()
{
    long long head, tail, freq;
    QueryPerformanceFrequency((LARGE_INTEGER*)&freq);
    QueryPerformanceCounter((LARGE_INTEGER*)&head);
    //��ʼ��barrier
    pthread_barrier_init(&barrier_eliminate,NULL,NUM_THREADS);
    pthread_barrier_init(&barrier_upgrade,NULL,NUM_THREADS);
    //�����߳�
    pthread_t handles[NUM_THREADS];
    threadParam_t param[NUM_THREADS];
    for(int t_id=0;t_id<NUM_THREADS;t_id++)
    {
        param[t_id].t_id=t_id;
        pthread_create(&handles[t_id],NULL,threadfuncAVX,&param[t_id]);
    }
    for(int t_id=0;t_id<NUM_THREADS;t_id++)
    {
        pthread_join(handles[t_id],NULL);
    }
    pthread_barrier_destroy(&barrier_eliminate);
    pthread_barrier_destroy(&barrier_upgrade);
    QueryPerformanceCounter((LARGE_INTEGER*)&tail);
    cout << "pthreadAVX: " << ((tail - head) * 1000.0 / freq) << "ms" << endl;
}

int main()
{
    for(int a=0;a<5;a++)
    {
    init_elim();
    init_beelimed();
    trivial();
    elim[N][N+1]={0};
    elimed[elimedN][N+1]={0};
    init_elim();
    init_beelimed();
    AVX();
    elim[N][N+1]={0};
    elimed[elimedN][N+1]={0};
    init_elim();
    init_beelimed();
    pthread();
    elim[N][N+1]={0};
    elimed[elimedN][N+1]={0};
    init_elim();
    init_beelimed();
    pthreadAVX();
    cout<<endl;
    }

}
